/*
 * Copyright Notice
 * 
 * (c) 2004 Darron Schall
 * http://solve.sourceforge.net
 * 
 * All rights reserved
 * 
 * 	This program and the accompanying materials are made available under
 *	the terms of the Common Public License v1.0 which accompanies this
 *	distribution, and is available at:  
 *			http://solve.sourceforge.net/cpl-v1.0.html
 *
 * This copyright notice MUST APPEAR in all copies of this file
 *
 * Contributors:
 *			Darron Schall - initial implementation
 */

package com.darronschall.swt.widgets;

import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;

/**
 * @author <a href="mailto:darron@darronschall.com>Darron Schall</a>
 */
public class StatusBar {

	Composite composite;
	Label label;
	
	int style;

	public StatusBar(Shell shell, int style) {
		this.style = style;
		
		composite = new Composite(shell, SWT.BORDER);
		GridLayout gl = new GridLayout();
		gl.marginWidth = gl.marginHeight = 2;
		composite.setLayout(gl);
		
		label = new Label(composite, SWT.NONE);
		label.setLayoutData(new GridData(GridData.FILL_HORIZONTAL));
	}

	public void setText(String str) {
		label.setText(str);
	}
	
	public void setLayoutData(Object data) {
		composite.setLayoutData(data);
	}
}

