/*
 * Copyright Notice
 * 
 * (c) 2004 Darron Schall
 * http://solve.sourceforge.net
 * 
 * All rights reserved
 * 
 * 	This program and the accompanying materials are made available under
 *	the terms of the Common Public License v1.0 which accompanies this
 *	distribution, and is available at:  
 *			http://solve.sourceforge.net/cpl-v1.0.html
 *
 * This copyright notice MUST APPEAR in all copies of this file
 *
 * Contributors:
 *			Darron Schall - initial implementation
 */

package com.darronschall.solve.gui;

import org.eclipse.swt.Sleak;

import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.DeviceData;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;

/**
 * @author <a href="mailto:darron@darronschall.com>Darron Schall</a>
 */
public class Launcher {
	
	// Set this to true to use S-leak and examine GUI for memory leaks
	private boolean useSleak = false;
	
	/**
	 *  
	 */
	public Launcher() {
		Display display;
		Shell splashShell;
		Shell appShell;
		Splash splash = null;
		SolVE app;
		
		if (useSleak) {
			DeviceData data = new DeviceData();
			data.tracking = true;
			display = new Display(data);
			Sleak sleak = new Sleak();
			sleak.open();
		} else {
			display = new Display();
		}
		
		appShell = new Shell(display);
		
		if (SettingsManager.showSplashOnStart) {
			splashShell = new Shell(display, SWT.NONE);
			// show the splash screen
			splash = new Splash(splashShell);
			splash.open();
		}
		
		// load the application
		app = new SolVE(appShell);
		app.open();
		
		if (splash != null) {
			// now that the app is loaded, remove the splash screen
			splash.dispose();	
		}
		
		while (!appShell.isDisposed()) {
			if (!display.readAndDispatch())
				display.sleep();
		}		
		display.dispose();
	}

	public static void main(String[] args) {
		new Launcher();
	}
}