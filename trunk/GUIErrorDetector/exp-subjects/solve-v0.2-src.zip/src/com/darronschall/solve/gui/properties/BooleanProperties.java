/*
 * Copyright Notice
 * 
 * (c) 2004 Darron Schall
 * http://solve.sourceforge.net
 * 
 * All rights reserved
 * 
 * 	This program and the accompanying materials are made available under
 *	the terms of the Common Public License v1.0 which accompanies this
 *	distribution, and is available at:  
 *			http://solve.sourceforge.net/cpl-v1.0.html
 *
 * This copyright notice MUST APPEAR in all copies of this file
 *
 * Contributors:
 *			Darron Schall - initial implementation
 */

package com.darronschall.solve.gui.properties;

import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.FormAttachment;
import org.eclipse.swt.layout.FormData;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Listener;

import com.darronschall.solve.datatypes.Boolean;
import com.darronschall.solve.gui.SolVE;

/**
 * @author <a href="mailto:darron@darronschall.com>Darron Schall</a>
 */
public class BooleanProperties extends PropertyPage {

	Boolean bool;
	
	protected Label valueLabel;
	protected Button trueButton;
	protected Button falseButton;
	
	public BooleanProperties(Composite parent, Boolean bool) {
		super(parent);
		this.bool = bool;
		
		initValues();
		updateI18N();
	}

	protected void initComponents() {
		super.initComponents();
		
		// Create the property name label
		valueLabel = new Label(contentHolder, SWT.RIGHT);
		
		FormData layoutData = new FormData();
		layoutData.top = new FormAttachment(propertyName, 14);
		layoutData.left = new FormAttachment(0, 0);
		layoutData.right = new FormAttachment(nameValue, -5);
		valueLabel.setLayoutData(layoutData);
				
		// Create true radio button
		trueButton = new Button(contentHolder, SWT.RADIO);
		
		layoutData = new FormData();
		layoutData.top = new FormAttachment(nameValue, 5);
		layoutData.left = new FormAttachment(valueLabel, 5);
		layoutData.right = new FormAttachment(100, 0);
		trueButton.setLayoutData(layoutData);
		
		// Create false radio button
		falseButton = new Button(contentHolder, SWT.RADIO);
		layoutData = new FormData();
		layoutData.top = new FormAttachment(trueButton, 5);
		layoutData.left = new FormAttachment(valueLabel, 5);
		layoutData.right = new FormAttachment(100, 0);
		falseButton.setLayoutData(layoutData);
		
		Listener radioGroup = new Listener () {
			public void handleEvent (Event event) {
				trueButton.setSelection(false);
				falseButton.setSelection(false);
				
				Button button = (Button) event.widget;
				button.setSelection (true);
				
				apply.setEnabled(true);
			}
		};
		
		trueButton.addListener(SWT.Selection, radioGroup);
		falseButton.addListener(SWT.Selection, radioGroup);
	}
	
	protected void initValues() {
		nameValue.setText(bool.getName());
		
		// check the appropriate radio box based on
		// the bool's value
		if (bool.getValue()) {
			trueButton.setSelection(true);
			falseButton.setSelection(false);
		} else {
			trueButton.setSelection(false);
			falseButton.setSelection(true);
		}
			
		initialValuesSet = true;
	}
	
	public void applyButtonPressed() {
		bool.setName(nameValue.getText());
		bool.setValue(trueButton.getSelection());
				
		super.applyButtonPressed();
	}
	
	public void updateI18N() {
		super.updateI18N();
		valueLabel.setText(SolVE.i18n.getResourceString("VALUE"));
		trueButton.setText(SolVE.i18n.getResourceString("TRUE"));
		falseButton.setText(SolVE.i18n.getResourceString("FALSE"));
	}
}
