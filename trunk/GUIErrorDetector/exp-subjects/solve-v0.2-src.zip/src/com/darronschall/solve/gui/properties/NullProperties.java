/*
 * Copyright Notice
 * 
 * (c) 2004 Darron Schall
 * http://solve.sourceforge.net
 * 
 * All rights reserved
 * 
 * 	This program and the accompanying materials are made available under
 *	the terms of the Common Public License v1.0 which accompanies this
 *	distribution, and is available at:  
 *			http://solve.sourceforge.net/cpl-v1.0.html
 *
 * This copyright notice MUST APPEAR in all copies of this file
 *
 * Contributors:
 *			Darron Schall - initial implementation
 */

package com.darronschall.solve.gui.properties;

import org.eclipse.swt.widgets.Composite;

import com.darronschall.solve.datatypes.Null;

/**
 * @author <a href="mailto:darron@darronschall.com>Darron Schall</a>
 */
public class NullProperties extends PropertyPage {

	Null n;
	
	public NullProperties(Composite parent, Null n) {
		super(parent);
		this.n = n;
		
		initValues();
		updateI18N();
	}
	
	protected void initValues() {
		nameValue.setText(n.getName());
		
		initialValuesSet = true;
	}
	
	public void applyButtonPressed() {
		n.setName(nameValue.getText());
			
		super.applyButtonPressed();	
	}
}
