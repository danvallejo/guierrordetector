/*
 * Copyright Notice
 * 
 * (c) 2004 Darron Schall
 * http://solve.sourceforge.net
 * 
 * All rights reserved
 * 
 * 	This program and the accompanying materials are made available under
 *	the terms of the Common Public License v1.0 which accompanies this
 *	distribution, and is available at:  
 *			http://solve.sourceforge.net/cpl-v1.0.html
 *
 * This copyright notice MUST APPEAR in all copies of this file
 *
 * Contributors:
 *			Darron Schall - initial implementation
 */

package com.darronschall.solve.gui.properties;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.KeyAdapter;
import org.eclipse.swt.events.KeyEvent;
import org.eclipse.swt.events.ModifyEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.layout.FormAttachment;
import org.eclipse.swt.layout.FormData;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Text;

import com.darronschall.solve.datatypes.String;
import com.darronschall.solve.gui.SolVE;

/**
 * @author <a href="mailto:darron@darronschall.com>Darron Schall</a>
 */
public class StringProperties extends PropertyPage {
	String str;
	
	protected Label valueLabel;
	protected Text stringValue;
	
	public StringProperties(Composite parent, String str) {
		super(parent);
		this.str = str;
		
		initValues();
		updateI18N();
	}
	
	protected void initComponents() {
		super.initComponents();
		
		// Create the property name label
		valueLabel = new Label(contentHolder, SWT.RIGHT);
		FormData layoutData = new FormData();
		layoutData.top = new FormAttachment(propertyName, 14);
		layoutData.left = new FormAttachment(0, 0);
		layoutData.right = new FormAttachment(nameValue, -5);
		valueLabel.setLayoutData(layoutData);
				
		// Create the property name text input
		stringValue = new Text(contentHolder, SWT.BORDER | SWT.MULTI);
		layoutData = new FormData();
		layoutData.top = new FormAttachment(nameValue, 5);
		layoutData.left = new FormAttachment(valueLabel, 5);
		layoutData.right = new FormAttachment(100, 0);
		layoutData.bottom = new FormAttachment(buttonHolder, 0);
		stringValue.setLayoutData(layoutData);
		
		// Whenever the name changes, the apply button needs
		// to be enabled
		stringValue.addModifyListener(new ModifyListener() {
			public void modifyText(ModifyEvent e) {
				if (initialValuesSet) {
					apply.setEnabled(true);
				}
			}
		});
		// If the user presses enter while in the text field
		// and the apply button is enabled, "click" the apply button
		stringValue.addKeyListener(new KeyAdapter() {
			public void keyPressed(KeyEvent e) {
				if (apply.getEnabled() && e.keyCode == SWT.CR) {
					applyButtonPressed();
				}
			}
		});
	}
	
	protected void initValues() {
		nameValue.setText(str.getName());
		stringValue.setText(str.getValue());
		
		initialValuesSet = true;
	}
	
	public void applyButtonPressed() {
		// TODO:  String msg = validate();
		// make sure to test for max string length
		
		str.setName(nameValue.getText());
		str.setValue(stringValue.getText());
			
		super.applyButtonPressed();	
	}
	
	public void updateI18N() {
		super.updateI18N();
		valueLabel.setText(SolVE.i18n.getResourceString("VALUE"));
	}
}
