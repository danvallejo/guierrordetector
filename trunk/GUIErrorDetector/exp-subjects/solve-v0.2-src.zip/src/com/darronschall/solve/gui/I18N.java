/*
 * Copyright Notice
 * 
 * (c) 2004 Darron Schall
 * http://solve.sourceforge.net
 * 
 * All rights reserved
 * 
 * 	This program and the accompanying materials are made available under
 *	the terms of the Common Public License v1.0 which accompanies this
 *	distribution, and is available at:  
 *			http://solve.sourceforge.net/cpl-v1.0.html
 *
 * This copyright notice MUST APPEAR in all copies of this file
 *
 * Contributors:
 *			Darron Schall - initial implementation
 */

package com.darronschall.solve.gui;

import java.io.InputStream;
import java.util.Locale;
import java.util.MissingResourceException;
import java.util.ResourceBundle;

/**
 * @author <a href="mailto:darron@darronschall.com>Darron Schall</a>
 */
public class I18N {

	private static ResourceBundle resources;
	//private static Locale locale;

	static {
		try {
			//locale = Locale.getDefault();
			// quick test:
			//locale = new Locale("bg_BG");
			
			resources = ResourceBundle.getBundle("resources.SolVE", 
					//locale
					Locale.getDefault());
		} catch (MissingResourceException mre) {
			System.err.println("resources/SolVE.properties not found");
			System.exit(1);
		}
	}
	
	public I18N() {
		
	}
	
	public final String getResourceString(String nm) {
		String str;
		try {
			str = resources.getString(nm);
		} catch (MissingResourceException mre) {
			str = null;
		}
		
		/*try {
			str = new String(str.getBytes(), "UTF8");
		} catch (Exception e) {
			str = null;
		}*/
		
		return str;
	}

	public final InputStream getResourceAsStream(String key) {
		String name = getResourceString(key);
		if (name != null) {
			return this.getClass().getResourceAsStream(name);
		}
		return null;
	}
	
	public void setLocale(String l) {
		//locale = new Locale(l);
		
		resources = ResourceBundle.getBundle("resources.SolVE",
				//locale
				// new Locale(l);
				new Locale(l.substring(0,2), l.substring(3))
				);
	}
	
	/*public Locale getLocale() {
		return locale;
	}*/

	
}
