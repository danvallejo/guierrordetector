/*
 * Copyright Notice
 * 
 * (c) 2004 Darron Schall
 * http://solve.sourceforge.net
 * 
 * All rights reserved
 * 
 * 	This program and the accompanying materials are made available under
 *	the terms of the Common Public License v1.0 which accompanies this
 *	distribution, and is available at:  
 *			http://solve.sourceforge.net/cpl-v1.0.html
 *
 * This copyright notice MUST APPEAR in all copies of this file
 *
 * Contributors:
 *			Darron Schall - initial implementation
 */

package com.darronschall.solve.gui.dialogs;

import org.eclipse.jface.dialogs.Dialog;
import org.eclipse.jface.dialogs.IDialogConstants;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.MouseAdapter;
import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;

import com.darronschall.solve.gui.SolVE;
import com.darronschall.util.BrowserUtility;
import com.darronschall.util.CursorUtility;
import com.darronschall.util.LayoutUtility;

/**
 * @author <a href="mailto:darron@darronschall.com">Darron Schall</a>
 */
public class AboutDialog extends Dialog {
	
	private static final int BANNER_WIDTH = 223;
	
	Image bannerImage;
	Image paypalImage;
	
	public AboutDialog(Shell parentShell) {
		super(parentShell);
	}
	
	/**
	 * @see org.eclipse.jface.window.Window#configureShell(org.eclipse.swt.widgets.Shell)
	 */
	protected void configureShell(Shell shell) {
		super.configureShell(shell);
		shell.setText(SolVE.i18n.getResourceString("ABOUT_TITLE"));
	}
	
	/**
	 * @see org.eclipse.jface.dialogs.Dialog#createDialogArea(org.eclipse.swt.widgets.Composite)
	 */
	protected Control createDialogArea(Composite parent) {
		GridLayout gl;
		GridData gd;
		
		// Composite to hold components
		Composite dialogArea = (Composite) super.createDialogArea(parent);
		dialogArea.setLayout(LayoutUtility.createGridLayout(1, 0, 0));
		
		gd = new GridData();
		gd.widthHint = BANNER_WIDTH + 200;
		dialogArea.setLayoutData(gd);
		
		Composite bannerHolder = new Composite(dialogArea, SWT.NONE);
		bannerHolder.setLayout(LayoutUtility.createGridLayout(1, 0, 0));
		bannerHolder.setBackground(parent.getDisplay().getSystemColor(SWT.COLOR_WHITE));
		bannerHolder.setLayoutData(new GridData(GridData.FILL_HORIZONTAL));
		
		bannerImage = new Image(parent.getDisplay(), SolVE.i18n.getResourceAsStream("ABOUT_BANNER_IMG"));
		Label aboutBanner = new Label(bannerHolder, SWT.NONE);
		aboutBanner.setImage(bannerImage);
		aboutBanner.setCursor(CursorUtility.handCursor);
		aboutBanner.setToolTipText("http://www.darronschall.com/solve");
		aboutBanner.addMouseListener(new MouseAdapter() {
			public void mouseUp(MouseEvent e) {
				BrowserUtility.openLink("http://www.darronschall.com/solve");
			}
		});	
		gd = new GridData(GridData.FILL_BOTH);
		gd.horizontalAlignment = SWT.CENTER;
		aboutBanner.setLayoutData(gd);
		
		
		Composite aboutContents = new Composite(dialogArea, SWT.NONE);
		gd = new GridData(GridData.FILL_BOTH);
		gd.grabExcessHorizontalSpace = true;
		gd.grabExcessVerticalSpace = true;
		aboutContents.setLayoutData(gd);
		aboutContents.setLayout(LayoutUtility.createGridLayout(1, 5, 5));
		
		Label copyrightText = new Label(aboutContents, SWT.WRAP);
		copyrightText.setText(SolVE.i18n.getResourceString("ABOUT_COPYRIGHT"));
		gd = new GridData();
		gd.horizontalAlignment = SWT.CENTER;
		copyrightText.setLayoutData(gd);
		
		Composite donateHolder = new Composite(aboutContents, SWT.NONE);
		donateHolder.setLayout(LayoutUtility.createGridLayout(2,1,0));
		gd = new GridData(GridData.FILL_BOTH);
		donateHolder.setLayoutData(gd);
		
		paypalImage = new Image(parent.getDisplay(), SolVE.i18n.getResourceAsStream("ABOUT_PAYPAL_IMG"));
		Label paypalBanner = new Label(donateHolder, SWT.NONE);
		paypalBanner.setImage(paypalImage);
		paypalBanner.setCursor(CursorUtility.handCursor);
		paypalBanner.setToolTipText(SolVE.i18n.getResourceString("ABOUT_DONATE_HINT"));
		paypalBanner.addMouseListener(new MouseAdapter() {
			public void mouseUp(MouseEvent e) {
				BrowserUtility.openLink("https://www.paypal.com/cgi-bin/webscr?cmd=_xclick&business=darron@darronschall.com&item_name=SolVE Donation&no_note=1&currency_code=USD&tax=0");
			}
		});
		gd = new GridData(GridData.FILL_VERTICAL);
		gd.verticalAlignment = SWT.CENTER;
		paypalBanner.setLayoutData(gd);
		
		// TODO:  can I add a mailto: around my email address?
		Label donateTextLabel = new Label(donateHolder, SWT.WRAP);
		donateTextLabel.setText(SolVE.i18n.getResourceString("ABOUT_DONATE_TEXT"));
		gd = new GridData(GridData.FILL_BOTH);
		gd.heightHint = 70;
		gd.verticalAlignment = SWT.CENTER;
		donateTextLabel.setLayoutData(gd);

		
		// TODO: make eric and jim linkable to their websites?
		Label thanksTextLabel = new Label(aboutContents, SWT.WRAP);
		thanksTextLabel.setText(SolVE.i18n.getResourceString("ABOUT_THANKS_TEXT"));
		gd = new GridData(GridData.FILL_BOTH);
		gd.horizontalAlignment = SWT.CENTER;
		gd.widthHint = BANNER_WIDTH + 150;
		thanksTextLabel.setLayoutData(gd);
		
		return dialogArea;
	}
	
	/**
	 * @see org.eclipse.jface.dialogs.Dialog#createButtonsForButtonBar(org.eclipse.swt.widgets.Composite)
	 */
	protected void createButtonsForButtonBar(Composite parent) {
		Button ok = createButton(parent, IDialogConstants.OK_ID, IDialogConstants.OK_LABEL, true);
	}

	/**
	 * @see org.eclipse.jface.dialogs.Dialog#close()
	 */
	public boolean close() {
		bannerImage.dispose();
		paypalImage.dispose();
		return super.close();
	}
}
