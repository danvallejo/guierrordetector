/*
 * Copyright Notice
 * 
 * (c) 2004 Darron Schall
 * http://solve.sourceforge.net
 * 
 * All rights reserved
 * 
 * 	This program and the accompanying materials are made available under
 *	the terms of the Common Public License v1.0 which accompanies this
 *	distribution, and is available at:  
 *			http://solve.sourceforge.net/cpl-v1.0.html
 *
 * This copyright notice MUST APPEAR in all copies of this file
 *
 * Contributors:
 *			Darron Schall - initial implementation
 */

package com.darronschall.solve.fileformat;

import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PushbackInputStream;

import com.darronschall.solve.datatypes.Array;
import com.darronschall.solve.datatypes.Boolean;
import com.darronschall.solve.datatypes.Null;
import com.darronschall.solve.datatypes.Number;
import com.darronschall.solve.datatypes.Object;
import com.darronschall.solve.datatypes.String;
import com.darronschall.solve.datatypes.Types;
import com.darronschall.solve.datatypes.Undefined;
import com.darronschall.solve.gui.SolVE;
import com.darronschall.util.IntegerUtility;

/**
 * @author <a href="mailto:darron@darronschall.com>Darron Schall</a>
 * 
 * Provides a static read method to read in a local shared object
 * from a file, and convert it to an Object datatype in memory.
 */
public class TCSOFileReader {

	/**
	 * Reads an Object datatype from a local shared object file
	 * 
	 * @param path	The path to the file
	 * @return The Object datatype read from the file
	 * @throws Exception	An Exception indicating some sort of read error
	 */
	public static Object read(java.lang.String path) throws Exception {
		File solFile;
		FileInputStream in = null;
		
		// the root object name is the name of the .sol file
		Object result = new Object("");
		
		try {
			solFile = new File(path);
			if (!TCSOFile.isValidFile(solFile, false, true)) {
				//return false;
			}
			in = new FileInputStream(solFile);
			
			readHeader(in);
			int length = readLen(in);
			length -= readFileType(in);
			length -= readPad(in);
			
			result.setName(readName(in));
			length -= 2; // name length
			length -= result.getName().getBytes("UTF8").length; // name value 
			length -= 4; // name pad
			
			// read until the end of the file
			while (length > 0) {
				//System.out.println("length left:" + length);
				length -= readDataType(in, result, false);
			}
			
		} catch (Exception e) {
			throw e;
		} finally {
			if (in != null) try { in.close(); } catch (IOException e) { ; }
		}
		
		return result;
	}
	
	private static void readHeader(InputStream in) throws IOException {
		byte header[] = new byte[2];
		
		in.read(header);
		if (!(header[0] == 0x00 && header[1] == (byte)0xBF)) {
			throw new IOException("Not a valid .sol file");
		}
	}
	
	// returns the length of the file
	private static int readLen(InputStream in) throws IOException {
		byte length[] = new byte[4];
		
		in.read(length); 
		
		return IntegerUtility.byteArrayToInt(length);
	}
	
	private static int readFileType(InputStream in) throws IOException {
		byte fileType[] = new byte[4];
		
		in.read(fileType);
		
		if (!(fileType[0] == 'T' && fileType[1] == 'C'
			&& fileType[2] == 'S' && fileType[3] == 'O')) {
			throw new IOException(SolVE.i18n.getResourceString("INVALID_FILE_FORMAT"));
		}
		
		return 4;
	}
	
	private static int readPad(InputStream in) throws IOException {
		byte pad[] = new byte[6];
		
		in.read(pad);
		
		if (!(pad[0] == 0 && pad[1] == 0x04 && pad[2] == 0
				&& pad[3] == 0 && pad[4] == 0 && pad[5] == 0)) {
			throw new IOException(SolVE.i18n.getResourceString("INVALID_FILE_FORMAT"));
		}
		
		return 6;
	}
	
	private static java.lang.String readName(InputStream in) throws IOException {
		byte length[] = new byte[2];
		
		in.read(length);
		
		byte name[] = new byte[IntegerUtility.byteArrayToShort(length)];
		in.read(name);
		
		// read the 4 bytes of 0 padding after the name
		in.read(length);
		in.read(length);
		
		return new java.lang.String(name, "UTF8");
	}
	
	private static int readDataType(InputStream in, Object data, boolean inObj) throws IOException {
		byte length[] = new byte[2];
		
		int bytesRead = 0;
				
		// read the name in
		in.read(length);
		bytesRead += length.length;
		byte nameBytes[] = new byte[IntegerUtility.byteArrayToShort(length)];
		
		in.read(nameBytes);
		bytesRead += nameBytes.length;
		java.lang.String utf8Name = new java.lang.String(nameBytes, "UTF8");

		int type = in.read();
		bytesRead += 1;
		
		// TODO:  the following code can probably be improved upon
		switch (type) {
			case Types.NUMBER: 
				Number num = new Number(utf8Name);
				bytesRead += readNumber(in, num, inObj);
				data.add(num);
				break;
				
			case Types.BOOLEAN:
				Boolean bool = new Boolean(utf8Name);
				bytesRead += readBoolean(in, bool, inObj);
				data.add(bool);
				break;
				
			case Types.STRING: 
				String str = new String(utf8Name);
				bytesRead += readString(in, str, inObj);
				data.add(str);
				break;
				
			case Types.OBJECT: 
				Object obj = new Object(utf8Name);
				bytesRead += readObject(in, obj, inObj); 
				data.add(obj);
				break;
				
			case Types.NULL:
				Null n = new Null(utf8Name);
				bytesRead += readNull(in, n, inObj);
				data.add(n);
				break;
			
			case Types.UNDEFINED:
				Undefined u = new Undefined(utf8Name);
				bytesRead += readUndefined(in, u, inObj);
				data.add(u);
				break;
				
			case Types.ARRAY:
				Array a = new Array(utf8Name);
				bytesRead += readArray(in, a, inObj);
				data.add(a);
				break;
				
			default:
				throw new IOException(SolVE.i18n.getResourceString("UNSUPPORTED_TYPE") + " " + type);
		}
		
		return bytesRead;
	}
	
	private static int readNumber(InputStream in, Number n, boolean inObj) throws IOException {
		DataInputStream in2 = new DataInputStream(in);
		
		n.setValue(in2.readDouble());
		
		int bytesRead = 8;
		if (!inObj) {
			in.read(); // read 0x00
			bytesRead += 1;
		}
		
		return bytesRead;
	}
	
	private static int readBoolean(InputStream in, Boolean b, boolean inObj) throws IOException {
		int bytesRead = 0;
		
		// because b defaults to false, we only need to set
		// the value if we read it as true
		if ((byte)in.read() == 0x01) {
			b.setValue(true);
		}
		bytesRead += 1;
		
		if (!inObj) {
			in.read(); // read 0x00
			bytesRead += 1;
		}
		
		return bytesRead;
		
	}
	
	private static int readNull(InputStream in, Null n, boolean inObj) throws IOException {
		int bytesRead = 0;
		
		// TODO: make sure the read here is 0x00
		in.read();
		bytesRead += 1;
		
		if (!inObj) {
			// TODO: make sure read is 00
			in.read(); // read 0x00
			bytesRead += 1;
		}
		
		return bytesRead;
	}
	
	private static int readUndefined(InputStream in, Undefined u, boolean inObj) throws IOException {
		int bytesRead = 0;
		
		// TODO: make sure the read here is 0x00
		in.read();
		bytesRead += 1;
		
		if (!inObj) {
			// TODO: make sure read is 00
			in.read(); // read 0x00
			bytesRead += 1;
		}
		
		return bytesRead;
	}
	
	// TODO: check all closing tags, etc
	private static int readString(InputStream in, String s, boolean inObj) throws IOException {
		int bytesRead = 0;
		
		byte length[] = new byte[2];
		
		in.read(length);
		bytesRead += length.length;
		
		byte value[] = new byte[IntegerUtility.byteArrayToShort(length)];
		in.read(value);
		bytesRead += value.length;
		
		s.setValue(new java.lang.String(value, "UTF8"));
		
		if (!inObj) {
			in.read(); // read 0x00
			bytesRead += 1;
		}
		
		return bytesRead;
	}
	
	// TODO: test for empty object compatibility
	// TODO: test for circular reference with global recursion depth
	// TODO: test how Flash write's LSO's with circular references
	private static int readObject(InputStream in, Object o, boolean inObj) throws IOException {
		int bytesRead = 0;
		byte end[] = new byte[3];
		boolean done = false;
		
		// TODO: shouldn't need to use a pushback reader here
		
		// 3 byte pushback to check for end of object sequence
		PushbackInputStream in2 = new PushbackInputStream(in, 3);
				
		in2.read(end);
		done = (end[0] == 0x00 && end[1] == 0x00 && end[2] == 0x09);
		bytesRead += end.length;
		
		//peek for 0x00 0x00 0x09
		while (!done) {
			// put the data back
			in2.unread(end);
			bytesRead -= 3;
			
		 	// get the next data type
			bytesRead += readDataType(in2, o, true);
		 	
		 	// peek for 0x00 0x00 0x09
			in2.read(end);
			done = (end[0] == 0x00 && end[1] == 0x00 && end[2] == 0x09);
			bytesRead += end.length;
		}
		
		if (!inObj) {
			in.read(); // read the 0x00 end marker
			bytesRead += 1;
		}
		
		return bytesRead;
	}
	
	private static int readArray(InputStream in, Array a, boolean inObj) throws IOException {
		int bytesRead = 0;
		
		// only difference between array and object seems to be
		// the count
		byte length[] = new byte[4];
		in.read(length);
		a.setLength(IntegerUtility.byteArrayToInt(length));
		bytesRead += length.length;
		
		byte end[] = new byte[3];
		boolean done = false;
		
		// TODO: shouldn't need to use a pushback reader here
		
		// 3 byte pushback to check for end of object sequence
		PushbackInputStream in2 = new PushbackInputStream(in, 3);
				
		in2.read(end);
		done = (end[0] == 0x00 && end[1] == 0x00 && end[2] == 0x09);
		bytesRead += end.length;
		
		//peek for 0x00 0x00 0x09
		while (!done) {
			// put the data back
			in2.unread(end);
			bytesRead -= 3;
			
		 	// get the next data type
			bytesRead += readDataType(in2, a, true);
		 	
		 	// peek for 0x00 0x00 0x09
			in2.read(end);
			done = (end[0] == 0x00 && end[1] == 0x00 && end[2] == 0x09);
			bytesRead += end.length;
		}
		
		if (!inObj) {
			in.read(); // read the 0x00 end marker
			bytesRead += 1;
		}
		
		return bytesRead;
	}
	
	private TCSOFileReader() {
		// protect from instantiation
	}
}
