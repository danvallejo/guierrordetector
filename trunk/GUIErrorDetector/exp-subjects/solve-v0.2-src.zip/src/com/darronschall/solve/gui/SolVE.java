/*
 * Copyright Notice
 * 
 * (c) 2004 Darron Schall
 * http://solve.sourceforge.net
 * 
 * All rights reserved
 * 
 * 	This program and the accompanying materials are made available under
 *	the terms of the Common Public License v1.0 which accompanies this
 *	distribution, and is available at:  
 *			http://solve.sourceforge.net/cpl-v1.0.html
 *
 * This copyright notice MUST APPEAR in all copies of this file
 *
 * Contributors:
 *			Darron Schall - initial implementation
 */

package com.darronschall.solve.gui;

import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.window.Window;
import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.SashForm;
import org.eclipse.swt.events.DisposeEvent;
import org.eclipse.swt.events.DisposeListener;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.Shell;

import com.darronschall.swt.widgets.StatusBar;
import com.darronschall.util.CursorUtility;
import com.darronschall.util.FontUtility;
import com.darronschall.util.LayoutUtility;

/**
 * @author <a href="mailto:darron@darronschall.com>Darron Schall</a>
 */
public class SolVE {

	private Shell shell;

	private EventManager eventManager;

	private SolVEMenu menu;

	public static I18N i18n = new I18N();

	// Flag is set to TRUE when application is closing
	public static boolean isClosing = false;

	// Flag set to true when changes were made without saving
	private boolean isDirty = false;

	private DataTree dataTree;

	private PropertyPane propertyPane;

	private Display display;
	
	private StatusBar statusBar;

	public static final int ASK_BEFORE_NEW = 0;

	public static final int ASK_BEFORE_OPEN = 1;

	public static final int ASK_BEFORE_CLOSE = 2;

	public static final int ASK_BEFORE_EXIT = 3;

	public SolVE(Shell shell) {
		this.shell = shell;
		this.display = shell.getDisplay();
		
		configureShell();
		startup();
	}

	public void open() {
		shell.open();
	}

	private void configureShell() {
		shell.setText(SolVE.i18n.getResourceString("TITLE"));

		GridLayout gl = LayoutUtility.createGridLayout(1,0,0);
		gl.verticalSpacing = 0;
		shell.setLayout(gl);
	}

	private void startup() {
		SettingsManager.initDefaultAccelerators();

		initComponents();

		CursorUtility.initCursors(display);

		FontUtility.initFonts(display);

		// TODO: load saved data and update as necessary
		// for now, just set to a default size
		shell.setSize(550, 375);
	}

	private void initComponents() {
		eventManager = new EventManager(shell, this);

		menu = new SolVEMenu(this);

		// Listen for close event to set isClosing and catch unsaved changes
		shell.addListener(SWT.Close, new Listener() {
			public void handleEvent(Event event) {
				checkSaveOnClose();
			}
		});

		SashForm sashForm = new SashForm(shell, SWT.NONE);
		dataTree = new DataTree(sashForm, this);
		propertyPane = new PropertyPane(sashForm, this);

		// TODO: load saved weights and update as necessary from SettingsManager
		sashForm.setWeights(new int[] { 45, 55 });
		sashForm.setLayoutData(new GridData(GridData.FILL_BOTH));
		
		statusBar = new StatusBar(shell, SWT.BORDER);
		statusBar.setLayoutData(new GridData(GridData.FILL_HORIZONTAL));
		
		shell.addDisposeListener(new DisposeListener() {
			public void widgetDisposed(DisposeEvent e) {
				shutdown();
			}
		});
	}

	private void shutdown() {
		CursorUtility.disposeCursors();

		FontUtility.disposeFonts();

		// TODO: save window size/location
		// TODO: save last opened file?
		// TODO: save recent file list?
		// TODO: save sash weights
	}
	
	public void updateI18N() {
		menu.updateI18N();
		propertyPane.updateI18N();
	}

	public Shell getShell() {
		return shell;
	}

	public PropertyPane getPropertyPane() {
		return propertyPane;
	}

	public DataTree getDataTree() {
		return dataTree;
	}

	public EventManager getEventManager() {
		return eventManager;
	}

	public void setStatusText(String text) {
		statusBar.setText(text);
	}
	
	public void setDirty(boolean dirty) {
		isDirty = dirty;
		String title = shell.getText();
		String dirtyLabel = i18n.getResourceString("DIRTY_LABEL"); 
			
		// update title with the dirty label as necessary
		if (isDirty) {
			if (!title.endsWith(dirtyLabel)) {
				shell.setText(title + dirtyLabel);
			}
		} 
		// remove the dirty label from the title
		else if (title.endsWith(dirtyLabel)) {
			shell.setText(title.substring(0, title.length() - dirtyLabel.length()));
		}
	}

	public boolean isDirty() {
		return isDirty;
	}

	private void checkSaveOnClose() {
		if (isDirty && SettingsManager.askSaveOnExit) {
			if (askSaveChanges(ASK_BEFORE_EXIT)) {
				if (eventManager.getFile() != null) {
					eventManager.actionSaveFile();
				} else {
					eventManager.actionSaveFileAs();
				}
			} else {
				// TODO: ask "Sure you want to exit without save?"
				// if (no) {
				//  isClosing = false;
				// (then change location of SolVE.isClosing, below as well)
				// }
			}
		}

		// exit application
		SolVE.isClosing = true;
	}

	public boolean askSaveChanges(int msgType) {
		String labels[] = {	i18n.getResourceString("LABEL_YES"), 
							i18n.getResourceString("LABEL_NO") };

		String msg = "";
		switch (msgType) {
			case ASK_BEFORE_NEW:
				msg = i18n.getResourceString("ASK_SAVE_BEFORE_NEW");
				break;
	
			case ASK_BEFORE_OPEN:
				msg = i18n.getResourceString("ASK_SAVE_BEFORE_OPEN");
				break;
	
			case ASK_BEFORE_CLOSE:
				msg = i18n.getResourceString("ASK_SAVE_BEFORE_CLOSE");
				break;
	
			case ASK_BEFORE_EXIT:
				msg = i18n.getResourceString("ASK_SAVE_BEFORE_EXIT");
				break;
		}

		// TODO: add a "never ask me again" option?

		MessageDialog saveDialog = new MessageDialog(shell, i18n.getResourceString("SAVE_TITLE"),
				Window.getDefaultImage(), msg, MessageDialog.QUESTION, labels,
				Window.OK);

		if (saveDialog.open() == Window.OK) {
			return true;
		} else {
			return false;
		}
	}
}

