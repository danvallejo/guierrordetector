/*
 * Copyright Notice
 * 
 * (c) 2004 Darron Schall
 * http://solve.sourceforge.net
 * 
 * All rights reserved
 * 
 * 	This program and the accompanying materials are made available under
 *	the terms of the Common Public License v1.0 which accompanies this
 *	distribution, and is available at:  
 *			http://solve.sourceforge.net/cpl-v1.0.html
 *
 * This copyright notice MUST APPEAR in all copies of this file
 *
 * Contributors:
 *			Darron Schall - initial implementation
 */

package com.darronschall.solve.datatypes;

/**
 * @author <a href="mailto:darron@darronschall.com>Darron Schall</a>
 * 
 * A String type is a DataType that holds a string as it's value
 */
public class String extends DataType {
	private java.lang.String value;
	
	/**
	 * @see com.darronschall.solve.datatypes.DataType
	 */
	public String(java.lang.String name) {
		super(name);
	}
	
	/**
	 * @param name	The "variable name" of the String
	 * @param value	The value of the String
	 */
	public String(java.lang.String name, java.lang.String value) {
		super(name);
		this.setValue(value);
	}
	
	/**
	 * @return The value of the String
	 */
	public java.lang.String getValue() {
		return this.value;
	}
	
	/**
	 * @param value	The value of the String
	 */
	public void setValue(java.lang.String value) {
		this.value = value;
	}
}
