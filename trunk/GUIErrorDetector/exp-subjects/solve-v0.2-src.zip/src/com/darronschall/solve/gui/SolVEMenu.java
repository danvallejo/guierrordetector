/*
 * Copyright Notice
 * 
 * (c) 2004 Darron Schall
 * http://solve.sourceforge.net
 * 
 * All rights reserved
 * 
 * 	This program and the accompanying materials are made available under
 *	the terms of the Common Public License v1.0 which accompanies this
 *	distribution, and is available at:  
 *			http://solve.sourceforge.net/cpl-v1.0.html
 *
 * This copyright notice MUST APPEAR in all copies of this file
 *
 * Contributors:
 *			Darron Schall - initial implementation
 */

package com.darronschall.solve.gui;

import java.util.Locale;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.widgets.Menu;
import org.eclipse.swt.widgets.MenuItem;

/**
 * @author <a href="mailto:darron@darronschall.com>Darron Schall</a>
 */
public class SolVEMenu {
	private EventManager eventManager;
	private SolVE gui;
	
	private boolean isMac;
	
	private Menu menu;
	private MenuItem fileItem;
	private MenuItem viewItem;
	private MenuItem helpItem;
	
	private Menu fileMenu;
	private MenuItem newItem;
	private MenuItem openItem;
	private MenuItem openPlayerFolderItem;
	private MenuItem closeItem;
	private MenuItem saveItem;
	private MenuItem saveAsItem;
	private MenuItem exitItem;
	
	private Menu viewMenu;
	private MenuItem languageItem;
	
	private Menu languageMenu;
	private MenuItem lang_en_US;
	private MenuItem lang_bg_BG;
	private MenuItem lang_fr_FR;
	private MenuItem lang_zh_CN;
	private MenuItem lang_zh_TW;
	
	private Menu helpMenu;
	private MenuItem aboutItem;
	
	public SolVEMenu(SolVE gui) {
		this.gui = gui;
		this.eventManager = gui.getEventManager();
		initComponents();
		updateAccelerators();
	}
	
	public void initComponents() {
		menu = new Menu(gui.getShell(), SWT.BAR);
		gui.getShell().setMenuBar(menu);
		
		createFileMenu();
		createViewMenu();
		createHelpMenu();
				
		// TODO: should this be here? maybe not...
		MenuManager.setNewState(MenuManager.NO_FILE_OPEN);
		// TODO: Should eventManager.actionSelectLanguage be called
		updateI18N();
	}
	
	private void createFileMenu() {
		fileItem = new MenuItem(menu, SWT.CASCADE);
		fileMenu = new Menu(gui.getShell(), SWT.DROP_DOWN);
		fileItem.setMenu(fileMenu);
		
		newItem = new MenuItem(fileMenu, SWT.CASCADE);
		newItem.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent arg0) {
				eventManager.actionNew();
			}
		});
		
		openItem = new MenuItem(fileMenu, SWT.CASCADE);
		openItem.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent arg0) {
				eventManager.actionOpenFile();
			}
		});
		
		// open from Player Folder is not available on
		// the mac because the open file dialog
		// does not support setting an initial filter path
		if (!SettingsManager.isMac) {
			openPlayerFolderItem = new MenuItem(fileMenu, SWT.CASCADE);
			openPlayerFolderItem.addSelectionListener(new SelectionAdapter() {
				public void widgetSelected(SelectionEvent arg0) {
					eventManager.actionOpenFile(true);
				}
			});
		}
		
		closeItem = new MenuItem(fileMenu, SWT.CASCADE);
		closeItem.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent arg0) {
				eventManager.actionClose();
			}
		});
		MenuManager.registerCloseItem(closeItem);
		
		new MenuItem(fileMenu, SWT.SEPARATOR);
		
		saveItem = new MenuItem(fileMenu, SWT.CASCADE);
		saveItem.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent arg0) {
				eventManager.actionSaveFile();
			}
		});
		
		saveAsItem = new MenuItem(fileMenu, SWT.CASCADE);
		saveAsItem.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent arg0) {
				eventManager.actionSaveFileAs();
			}
		});
		
		MenuManager.registerSaveItems(saveItem, saveAsItem);
		
		new MenuItem(fileMenu, SWT.SEPARATOR);
		
		exitItem = new MenuItem(fileMenu, SWT.CASCADE);
		exitItem.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent arg0) {
				eventManager.actionExit();
			}
		});
	}
	
	private void createViewMenu() {
		viewItem = new MenuItem(menu, SWT.CASCADE);
		viewMenu = new Menu(gui.getShell(), SWT.DROP_DOWN);
		viewItem.setMenu(viewMenu);
		
		languageItem = new MenuItem(viewMenu, SWT.CASCADE);
		languageMenu = new Menu(gui.getShell(), SWT.DROP_DOWN);
		languageItem.setMenu(languageMenu);
		
		lang_bg_BG = new MenuItem(languageMenu, SWT.CASCADE | SWT.RADIO);
		lang_bg_BG.setData("bg_BG");
		
		lang_zh_CN = new MenuItem(languageMenu, SWT.CASCADE | SWT.RADIO);
		lang_zh_CN.setData("zh_CN");
		
		lang_zh_TW = new MenuItem(languageMenu, SWT.CASCADE | SWT.RADIO);
		lang_zh_TW.setData("zh_TW");
		
		lang_en_US = new MenuItem(languageMenu, SWT.CASCADE | SWT.RADIO);
		lang_en_US.setData("en_US");
		
		lang_fr_FR = new MenuItem(languageMenu, SWT.CASCADE | SWT.RADIO);
		lang_fr_FR.setData("fr_FR");
		
		// select the default language based on Locale
		//String l = SolVE.i18n.getLocale().toString().toLowerCase();
		String l = Locale.getDefault().toString().toLowerCase();
		if (l.equals("bg_bg")) {
			lang_bg_BG.setSelection(true);
		} else if (l.equals("zh_cn")) {
			lang_zh_CN.setSelection(true);
		} else if (l.equals("zh_tw")) {
			lang_zh_TW.setSelection(true);
		} else if (l.equals("en_us")) {
			lang_en_US.setSelection(true);
		} else if (l.equals("fr_fr")) {
			lang_fr_FR.setSelection(true);
		}
		
		SelectionAdapter selectLang = new SelectionAdapter() {
			public void widgetSelected(SelectionEvent arg0) {
				eventManager.actionSelectLanguage(arg0);
			}
		};
		
		lang_en_US.addSelectionListener(selectLang);
		lang_bg_BG.addSelectionListener(selectLang);
		lang_fr_FR.addSelectionListener(selectLang);
		lang_zh_CN.addSelectionListener(selectLang);
		lang_zh_TW.addSelectionListener(selectLang);
		
	}
	
	private void createHelpMenu() {
		helpItem = new MenuItem(menu, SWT.CASCADE);
		helpMenu = new Menu(gui.getShell(), SWT.DROP_DOWN);
		helpItem.setMenu(helpMenu);
		
		aboutItem = new MenuItem(helpMenu, SWT.CASCADE);
		aboutItem.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent arg0) {
				eventManager.actionOpenAbout();
			}
		});
	}
	
	public void updateI18N() {
		fileItem.setText(SolVE.i18n.getResourceString("MENU_FILE"));
		newItem.setText(SolVE.i18n.getResourceString("MENU_NEW"));
		openItem.setText(SolVE.i18n.getResourceString("MENU_OPEN"));
		if (openPlayerFolderItem != null) {
			openPlayerFolderItem.setText(SolVE.i18n.getResourceString("MENU_OPEN_PLAYER"));
		}
		closeItem.setText(SolVE.i18n.getResourceString("MENU_CLOSE"));
		saveItem.setText(SolVE.i18n.getResourceString("MENU_SAVE"));
		saveAsItem.setText(SolVE.i18n.getResourceString("MENU_SAVEAS"));
		exitItem.setText(SolVE.i18n.getResourceString("MENU_EXIT"));
		
		viewItem.setText("View");
		languageItem.setText("Language");
		lang_bg_BG.setText("Bulgarian (Bulgaria)");
		lang_zh_CN.setText("Chinese (Simplified)");
		lang_zh_TW.setText("Chinese (Traditional)");
		lang_en_US.setText("English (US)");
		lang_fr_FR.setText("French (France)");
		
		helpItem.setText(SolVE.i18n.getResourceString("MENU_HELP"));
		aboutItem.setText(SolVE.i18n.getResourceString("MENU_ABOUT"));
	}
	
	public void updateAccelerators() {
		// file menu
		updateAccelerator(newItem, "MENU_NEW");
		updateAccelerator(openItem, "MENU_OPEN");
		updateAccelerator(openPlayerFolderItem, "MENU_OPEN_PLAYER");
		updateAccelerator(closeItem, "MENU_CLOSE");
		updateAccelerator(saveItem, "MENU_SAVE");
		updateAccelerator(exitItem, "MENU_EXIT");
	}
	
	public void updateAccelerator(MenuItem menuItem, String command) {
		if (menuItem == null) return;
		
		menuItem.setAccelerator(Integer.parseInt(((String [])SettingsManager.hotKeys.get(command))[1]));
		
		// if the accelerator exists, update the menu text to display it - 
		// the Mac OS Menu-Manager will add the accelerator as text to the menuitem,
		// so we only have to add the command on other platforms
		if (menuItem.getAccelerator() > 0 && !isMac) {
			menuItem.setText(menuItem.getText() + "\t" + ((String [])SettingsManager.hotKeys.get(command))[0]);
		}
	}
}