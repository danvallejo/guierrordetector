
package com.darronschall.solve.test;

import com.darronschall.solve.datatypes.Number;
import com.darronschall.solve.datatypes.Object;
import com.darronschall.solve.fileformat.TCSOFileReader;
import com.darronschall.solve.fileformat.TCSOFileWriter;

public class ReadWriteTest {

	public static void main(java.lang.String[] args) {
		 
		Object root = new Object("tester");
		Object obj1 = new Object("obj1");
		obj1.add(new Number("num", 2));
		Object nest1 = new Object("nest1");
		nest1.add(new Number("num1", 3));
		Object nest2 = new Object("nest2");
		nest2.add(new Number("num1", 4));
		nest1.add(nest2);
		obj1.add(nest1);
		
		Object obj2 = new Object("obj2");
		obj2.add(new Number("num1", 17.5));
		
		root.add(obj1);
		root.add(obj2);
		root.add(new Number("num18", 18));
		
				
		/* -----------------------------
		Object root = new Object("tester");
		Object dObj = new Object("dObject");
		dObj.add(new Number("num2", 3));
		dObj.add(new String("str1", "test1"));
		dObj.add(new String("str2", "test2"));
		
		Object newObject = new Object("newObject");
		newObject.add(new String("stringTest", "again"));
		newObject.add(new Number("numberTest", 12));
		dObj.add(newObject);
		//Array arr = new Array("test_arr");
		//arr.addItemAt(0, new String("stest1", "hello world"));
		//root.add(arr);
		root.add(new Number("num1", 23.5));
		root.add(dObj);
		---------------------- */
		
		java.lang.String path = "";
		
		java.lang.String path2 = path + "tester.sol";
		java.lang.String path3 = path + "tester_new.sol";
		
		//TCSOFileWriter.write(path, root);
		
		Object newRoot = TCSOFileReader.read(path2);
		
		//TCSOFileWriter.write(path3, newRoot);
	}
}

