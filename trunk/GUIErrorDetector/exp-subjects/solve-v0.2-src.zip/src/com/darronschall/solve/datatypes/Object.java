/*
 * Copyright Notice
 * 
 * (c) 2004 Darron Schall
 * http://solve.sourceforge.net
 * 
 * All rights reserved
 * 
 * 	This program and the accompanying materials are made available under
 *	the terms of the Common Public License v1.0 which accompanies this
 *	distribution, and is available at:  
 *			http://solve.sourceforge.net/cpl-v1.0.html
 *
 * This copyright notice MUST APPEAR in all copies of this file
 *
 * Contributors:
 *			Darron Schall - initial implementation
 */
package com.darronschall.solve.datatypes;

import java.util.Iterator;
import java.lang.String;

/**
 * @author <a href="mailto:darron@darronschall.com>Darron Schall</a>
 * 
 * Object is a generic DataType container
 */
public class Object extends ContainerType {
	
	/**
	 * @see com.darronschall.solve.datatypes.DataType
	 */
	public Object(String name) {
		super(name);
	}
	
	/**
	 * @see com.darronschall.solve.datatypes.ContainerType#add(com.darronschall.solve.datatypes.DataType)
	 */
	public boolean add(DataType item) {
		return data.add(item);
	}
	
	/**
	 * @see com.darronschall.solve.datatypes.ContainerType#contains(com.darronschall.solve.datatypes.DataType)
	 */
	public boolean contains(DataType item) {
		return contains(item.getName());
	}
	
	/**
	 * @see com.darronschall.solve.datatypes.ContainerType#contains(java.lang.String)
	 */
	public boolean contains(java.lang.String name) {
		Iterator it = iterator();
		while (it.hasNext()) {
			DataType data = (DataType)it.next();
			// TODO: case insensative?  does the .sol differentiate?
			if (data.getName().equals(name)) {
				return true;
			}
		}
		return false;
	}
 	
	/**
	 * @see com.darronschall.solve.datatypes.ContainerType#remove(com.darronschall.solve.datatypes.DataType)
	 */
	public boolean remove(DataType item) {
		return data.remove(item);
	}

	public Iterator iterator() {
		return data.iterator();
	}
}
