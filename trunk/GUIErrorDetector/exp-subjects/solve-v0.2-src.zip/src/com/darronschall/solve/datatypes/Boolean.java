/*
 * Copyright Notice
 * 
 * (c) 2004 Darron Schall
 * http://solve.sourceforge.net
 * 
 * All rights reserved
 * 
 * 	This program and the accompanying materials are made available under
 *	the terms of the Common Public License v1.0 which accompanies this
 *	distribution, and is available at:  
 *			http://solve.sourceforge.net/cpl-v1.0.html
 *
 * This copyright notice MUST APPEAR in all copies of this file
 *
 * Contributors:
 *			Darron Schall - initial implementation
 */

package com.darronschall.solve.datatypes;

import java.lang.String;

/**
 * @author <a href="mailto:darron@darronschall.com>Darron Schall</a>
 * 
 * A Boolean type is a DataType that holds a value of either true or false
 */
public class Boolean extends DataType {
	
	private boolean value = false;
	
	/**
	 * @see com.darronschall.solve.datatypes.DataType
	 */
	public Boolean(String name) {
		super(name);
	}
	
	/**
	 * @param name	The "variable name" of the Boolean
	 * @param value	The value of the Boolean
	 */
	public Boolean(String name, boolean value) {
		super(name);
		this.setValue(value);
	}
	
	/**
	 * @return	The value of the Boolean
	 */
	public boolean getValue() {
		return this.value;
	}
	
	/**
	 * @param value	The value of the Boolean
	 */
	public void setValue(boolean value) {
		this.value = value;
	}
}
