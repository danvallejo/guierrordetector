/*
 * Copyright Notice
 * 
 * (c) 2004 Darron Schall
 * http://solve.sourceforge.net
 * 
 * All rights reserved
 * 
 * 	This program and the accompanying materials are made available under
 *	the terms of the Common Public License v1.0 which accompanies this
 *	distribution, and is available at:  
 *			http://solve.sourceforge.net/cpl-v1.0.html
 *
 * This copyright notice MUST APPEAR in all copies of this file
 *
 * Contributors:
 *			Darron Schall - initial implementation
 */

package com.darronschall.solve.fileformat;

import java.io.File;

import com.darronschall.solve.gui.SolVE;

/**
 * @author <a href="mailto:darron@darronschall.com>Darron Schall</a>
 *
 * Provides static method(s) to verify "on the surface" that a file is
 * a valid file and that the user is able to interact with it.
 */
public class TCSOFile {
		
	/**
	 * Determines if a file is valid (without examining the data in the file)
	 * 
	 * @param solFile	The file to test for validity against
	 * @param read	true if the user is going to be reading the file
	 * @param write	true if the user is going to be writing to the fil
	 * @return	true iff the file meets all of the necessary criteria to be valid
	 * @throws Exception Exception indicating what part of the validation failed
	 */
	public static boolean isValidFile(File solFile, boolean read, boolean write) throws Exception {
		
		// first make sure the extension is valid, then validate file
		// based on read and write flags
		if (!solFile.getName().endsWith(".sol")) {
			throw new Exception(SolVE.i18n.getResourceString("INVALID_EXTENSION"));
		}
		
		if (read) {
			if (!solFile.exists()) {
				throw new Exception(SolVE.i18n.getResourceString("FILE_NOT_EXIST"));
			} else if (!solFile.isFile()) {
				throw new Exception(SolVE.i18n.getResourceString("NOT_A_FILE"));
			} else if (!solFile.canRead()) {
				throw new Exception(SolVE.i18n.getResourceString("CANNOT_READ_FILE"));
			}
		}
		
		if (write) {
			if (!solFile.exists()) {
				solFile.createNewFile();
			}
			if (!solFile.canWrite()) {
				throw new Exception(SolVE.i18n.getResourceString("CANNOT_WRITE_FILE"));
			}
		}

		return true;
	}
	
	private TCSOFile() {
		// protect from instantiation
	}
}
