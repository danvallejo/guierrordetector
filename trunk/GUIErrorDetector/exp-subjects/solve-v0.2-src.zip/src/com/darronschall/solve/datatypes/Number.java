/*
 * Copyright Notice
 * 
 * (c) 2004 Darron Schall
 * http://solve.sourceforge.net
 * 
 * All rights reserved
 * 
 * 	This program and the accompanying materials are made available under
 *	the terms of the Common Public License v1.0 which accompanies this
 *	distribution, and is available at:  
 *			http://solve.sourceforge.net/cpl-v1.0.html
 *
 * This copyright notice MUST APPEAR in all copies of this file
 *
 * Contributors:
 *			Darron Schall - initial implementation
 */

package com.darronschall.solve.datatypes;

import java.lang.String;

/**
 * @author <a href="mailto:darron@darronschall.com>Darron Schall</a>
 * 
 * A Number type is a DataType that holds a double as it's value
 */
public class Number extends DataType {
	
	private double value = 0;
	
	/**
	 * @see com.darronschall.solve.datatypes.DataType
	 */
	public Number(String name) {
		super(name);
	}
	
	/**
	 * @param name	The "variable name" of the Number
	 * @param value	The value of the Number
	 */
	public Number(String name, double value) {
		super(name);
		this.setValue(value);
	}
	
	/**
	 * @return	The value of the Number
	 */
	public double getValue() {
		return this.value;
	}
	
	/**
	 * @param value	The value of the Number
	 */
	public void setValue(double value) {
		this.value = value;
	}
}
