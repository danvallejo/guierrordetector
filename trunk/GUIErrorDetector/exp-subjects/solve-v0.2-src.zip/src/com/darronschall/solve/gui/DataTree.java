/*
 * Copyright Notice
 * 
 * (c) 2004 Darron Schall
 * http://solve.sourceforge.net
 * 
 * All rights reserved
 * 
 * 	This program and the accompanying materials are made available under
 *	the terms of the Common Public License v1.0 which accompanies this
 *	distribution, and is available at:  
 *			http://solve.sourceforge.net/cpl-v1.0.html
 *
 * This copyright notice MUST APPEAR in all copies of this file
 *
 * Contributors:
 *			Darron Schall - initial implementation
 */

package com.darronschall.solve.gui;

import java.util.Iterator;

import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.SashForm;
import org.eclipse.swt.events.KeyAdapter;
import org.eclipse.swt.events.KeyEvent;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.Menu;
import org.eclipse.swt.widgets.Tree;
import org.eclipse.swt.widgets.TreeItem;

import com.darronschall.solve.datatypes.Array;
import com.darronschall.solve.datatypes.Boolean;
import com.darronschall.solve.datatypes.ContainerType;
import com.darronschall.solve.datatypes.DataType;
import com.darronschall.solve.datatypes.Null;
import com.darronschall.solve.datatypes.Number;
import com.darronschall.solve.datatypes.Object;
import com.darronschall.solve.datatypes.String;
import com.darronschall.solve.datatypes.Undefined;
import com.darronschall.solve.gui.popup.DataTreePopup;

/**
 * @author <a href="mailto:darron@darronschall.com>Darron Schall</a>
 */
public class DataTree {

	private SashForm contentPane;

	private SolVE gui;

	private EventManager eventManager;
	
	private Tree tree;

	DataTreePopup dataTreePopup;
	
	/**
	 * Instantiate a new DataTree
	 */
	public DataTree(SashForm contentPane, SolVE gui) {
		this.contentPane = contentPane;
		this.gui = gui;
		eventManager = gui.getEventManager();
		initComponents();
	}

	private void initComponents() {

		tree = new Tree(this.contentPane, SWT.BORDER);
		//TODO: need to only add listeners when values are set - 
		// workaround for now is to test for getSelect().length
		// Expand / Collapse item on pressed enter key
		tree.addKeyListener(new KeyAdapter() {
			public void keyPressed(KeyEvent e) {
				if (tree.getSelection().length > 0) {
					TreeItem selectedItem = tree.getSelection()[0];
					if (e.keyCode == SWT.CR && selectedItem.getItemCount() > 0)
						selectedItem.setExpanded(!selectedItem.getExpanded());
				}
				
			}
		});

		// Expand / Collapse selection on double click
		tree.addListener(SWT.MouseDoubleClick, new Listener() {
			public void handleEvent(Event event) {
				if (tree.getSelectionCount() > 0) {
					Rectangle clickedRect = event.getBounds();
					Rectangle selectedRect = tree.getSelection()[0].getBounds();

					/** Only handle event, if Mouse is over treeitem */
					if (selectedRect.contains(clickedRect.x, clickedRect.y))
						tree.getSelection()[0]
								.setExpanded(!tree.getSelection()[0]
										.getExpanded());
				}
			}
		});

		tree.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				gui.getEventManager().actionTreeItemSelected();
			}
		});
	
		// create the popup menu
		dataTreePopup = new DataTreePopup(gui);
		tree.setMenu(dataTreePopup.getTreePopupMenu());
	}
	
	public void configurePopupMenu() {
		if (tree.getSelectionCount() == 1) {
			TreeItem selectedItem = tree.getSelection()[0];
			
			if (selectedItem.getParentItem() == null) {
				dataTreePopup.configureMenu(DataTreePopup.ROOT_MENU);
			} else {
				DataType data = (DataType) selectedItem.getData();
				
				if (data instanceof ContainerType) {
					dataTreePopup.configureMenu(DataTreePopup.CONTAINER_MENU);	
				} else {
					dataTreePopup.configureMenu(DataTreePopup.NON_CONTAINER_MENU);
				}
			}
		} else {
			dataTreePopup.configureMenu(DataTreePopup.EMPTY_MENU);
		}
		
	}
	
	public void updateLabel(TreeItem item) {
		DataType data = (DataType)item.getData();
		
		// TODO: this code could possibly be improved
		if (data instanceof Array) {
			item.setText(data.getName() + ": " 
						+ "array"); // TODO: i18n
		} else if (data instanceof Object) { 
			item.setText(data.getName() + ": " 
					+ SolVE.i18n.getResourceString("OBJECT_POPUP"));
		} else if (data instanceof Number) {
			// TODO: Format number
			item.setText(data.getName() + ": " + ((Number)data).getValue());
		} else if (data instanceof String) {
			item.setText(data.getName() + ": " + ((String)data).getValue());
		} else if (data instanceof Boolean) {
			if (((Boolean)data).getValue() == true) {
				item.setText(data.getName() + ": " + SolVE.i18n.getResourceString("TRUE"));
			} else {
				item.setText(data.getName() + ": " + SolVE.i18n.getResourceString("FALSE"));
			}
		} else if (data instanceof Null) {
			item.setText(data.getName() + ": " 
					+ SolVE.i18n.getResourceString("NULL_POPUP"));
		} else if (data instanceof Undefined) {
			item.setText(data.getName() + ": "
					+ SolVE.i18n.getResourceString("UNDEFINED_POPUP"));
		}
	}
	
	public TreeItem getSelectedItem() {
		if (tree.getSelectionCount() > 0) {
			return tree.getSelection()[0];
		} else {
			return null;
		}
	}
	
	public DataType getSelectedData() {
		if (getSelectedItem() != null) {
			return (DataType) getSelectedItem().getData();
		} else {
			return null;
		}
	}
	
	public Object getDataObject() {
		return (Object)tree.getTopItem().getData();
	}
	
	public void setDataObject(Object data) {		
		tree.removeAll();
		
		TreeItem root = new TreeItem(tree, SWT.NONE);
		root.setText(data.getName());
		root.setData(data);
		
		updateLabel(root);
		
		Iterator it = data.iterator();
		while (it.hasNext()) {
			DataType nested = (DataType)it.next();
			createDataType(nested, root);			
		}	
		
		expandAll();
	}
	
	private void createDataType(DataType data, TreeItem parent) {
		TreeItem nested = new TreeItem(parent, SWT.NONE);
		nested.setText(data.getName());
		nested.setData(data);
		
		updateLabel(nested);
		
		if (data instanceof Object) {
			Iterator it = ((Object)data).iterator();
			while (it.hasNext()) {
				DataType nestedDeeper = (DataType)it.next();
				createDataType(nestedDeeper, nested);
			}
		}	
	}
	
	/** 
	 * Expands all of the elements in the tree
	 */
	public void expandAll() {
		expandAll(tree.getTopItem());
	}
	
	/**
	 * Expands item and all of the elements below it
	 *  
	 * @param item	The root item to start expanding from
	 */
	public void expandAll(TreeItem item) {
	    if (item != null) {
	        item.setExpanded(true);
	        TreeItem items[] = item.getItems(); 
	        for (int i = 0; i < items.length; i++) {
	            expandAll(items[i]);
	        }
	    }
	}
	
	/** 
	 * Empties the contents of the tree 
	 */
	public void empty() {
		tree.removeAll();
	}
	
	public void setMenu(Menu menu) {
		tree.setMenu(menu);
	}

}