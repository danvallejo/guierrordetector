/*
 * Copyright Notice
 * 
 * (c) 2004 Darron Schall
 * http://solve.sourceforge.net
 * 
 * All rights reserved
 * 
 * 	This program and the accompanying materials are made available under
 *	the terms of the Common Public License v1.0 which accompanies this
 *	distribution, and is available at:  
 *			http://solve.sourceforge.net/cpl-v1.0.html
 *
 * This copyright notice MUST APPEAR in all copies of this file
 *
 * Contributors:
 *			Darron Schall - initial implementation
 */

package com.darronschall.solve.datatypes;

import java.util.ArrayList;

/**
 * @author <a href="mailto:darron@darronschall.com>Darron Schall</a>
 * 
 * A ContainerType is a DataType that can store other DataTypes
 * inside of it (such as Object and Array).  This abstract
 * class is not meant to be instantiated, but rather it is useful
 * for determining if a DataType is a container.
 */
public abstract class ContainerType extends DataType {

	protected ArrayList data;
	
	/**
	 * @see com.darronschall.solve.datatypes.DataType
	 */
	public ContainerType(java.lang.String name) {
		super(name);
		data = new ArrayList();
	}
	
	/**
	 * Adds a DataType as a child in the container
	 * 
	 * @param item	The DataType to add
	 * @return true iff the item was added successfully
	 */
	public abstract boolean add(DataType item);
	
	/**
	 * Determines if the container has a child with the
	 * same "variable name" as item.  This DOES NOT test
	 * for equality (meaning the item itself is contained),
	 * but rather only tests for an item with the same
	 * "variable name" as a member in the container.
	 * 
	 * @param item	The item containing a "variaible name" 
	 * 		to see if a child exists with the same name
	 * @return true iff there exists a child with the same 
	 * 		"variable name" as item 
	 */
	public abstract boolean contains(DataType item);
	
	/**
	 * Determines if the container has a child with the
	 * same "variable name" as that of name.
	 * 
	 * @param name	The "variable" to test for
	 * @return true iff there exists a child with a "variable 
	 * 		name" equal to name
	 */
	public abstract boolean contains(java.lang.String name);
	
	/**
	 * Removes a DataType from the container, if it
	 * is a member
	 * 
	 * @param item	The DataType to remove
	 * @return true iff the item was in the container
	 */
	public abstract boolean remove(DataType item);
}
