/*
 * Copyright Notice
 * 
 * (c) 2004 Darron Schall
 * http://solve.sourceforge.net
 * 
 * All rights reserved
 * 
 * 	This program and the accompanying materials are made available under
 *	the terms of the Common Public License v1.0 which accompanies this
 *	distribution, and is available at:  
 *			http://solve.sourceforge.net/cpl-v1.0.html
 *
 * This copyright notice MUST APPEAR in all copies of this file
 *
 * Contributors:
 *			Darron Schall - initial implementation
 */

package com.darronschall.solve.gui.properties;

import java.util.Observable;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.KeyAdapter;
import org.eclipse.swt.events.KeyEvent;
import org.eclipse.swt.events.ModifyEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.FormAttachment;
import org.eclipse.swt.layout.FormData;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Text;

import com.darronschall.solve.gui.SolVE;
import com.darronschall.util.LayoutUtility;

/**
 * @author <a href="mailto:darron@darronschall.com>Darron Schall</a>
 */
public abstract class PropertyPage extends Observable {
	
	public static final String PROPERTY_APPLY_SUCCESS = "0";
	public static final String PROPERTY_APPLY_FAILURE = "1";
	
	//public static final int LEFT_WIDTH = 80;
	
	protected Label propertyName;
	protected Text nameValue;
	protected Button apply;
	
	// holds the property page content
	protected Composite contentHolder;
	
	protected Composite buttonHolder;
		
	// parent of the composite
	protected Composite parent;
	
	// when we initialize the values, the modify listener
	// fires, so we use a boolean flag to make sure
	// the listener doesn't execute
	protected boolean initialValuesSet = false;
	
	/**
	 * Instantiates a new PropertyPage
	 * 
	 * @param parent Composite's parent
	 */
	public PropertyPage(Composite parent) {
		this.parent = parent;
		
		createContentHolder();
		createApply();
		initComponents();
	}
	
	/** 
	 * Create the composite that holds the PropertyPage 
	 */
	protected void createContentHolder() {
		contentHolder = new Composite(parent, SWT.NONE);
		contentHolder.setLayout(LayoutUtility.createFormLayout(0, 0, 3));
		
		FormData layoutData = new FormData();
		layoutData.top = new FormAttachment(0, 0);
		layoutData.left = new FormAttachment(0, 0);
		layoutData.right = new FormAttachment(100, 0);
		layoutData.bottom = new FormAttachment(100, 0);
		contentHolder.setLayoutData(layoutData);
	}
	
	
	/** 
	 * Initialize all components 
	 */
	protected void initComponents() {
		// Create the property name label
		propertyName = new Label(contentHolder, SWT.RIGHT);
		FormData layoutData = new FormData();
		layoutData.top = new FormAttachment(0, 7);
		layoutData.left = new FormAttachment(0, 0);
		propertyName.setLayoutData(layoutData);
				
		// Create the property name text input
		nameValue = new Text(contentHolder, SWT.BORDER);
		layoutData = new FormData();
		layoutData.top = new FormAttachment(0, 5);
		layoutData.left = new FormAttachment(propertyName, 5);
		layoutData.right = new FormAttachment(100, 0);
		nameValue.setLayoutData(layoutData);
		
		// Whenever the name changes, the apply button needs
		// to be enabled
		nameValue.addModifyListener(new ModifyListener() {
			public void modifyText(ModifyEvent e) {
				if (initialValuesSet) {
					apply.setEnabled(true);
				}
			}
		});
		// If the user presses enter while in the text field
		// and the apply button is enabled, "click" the apply button
		nameValue.addKeyListener(new KeyAdapter() {
			public void keyPressed(KeyEvent e) {
				if (apply.getEnabled() && e.keyCode == SWT.CR) {
					applyButtonPressed();
				}
			}
		});
	}

	/** 
	 * Create "Apply" button 
	 */
	protected void createApply() {
		buttonHolder = new Composite(contentHolder, SWT.NONE);
		
		// button to apply the changes made
		apply = new Button(buttonHolder, SWT.PUSH);
		apply.setSize(80, 26);
		apply.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				applyButtonPressed();
			}
		});
		
		FormData layoutData = new FormData();
		layoutData.bottom = new FormAttachment(100, 0);
		layoutData.right = new FormAttachment(100, 0);
		buttonHolder.setLayoutData(layoutData);
		
		apply.setEnabled(false);
	}
		
	/** 
	 * The apply button has been pressed 
	 */
	public void applyButtonPressed() {
		applyButtonPressed(true, "");
	}
	
	public void applyButtonPressed(boolean valid, String msg) {
		if (valid) {
			apply.setEnabled(false);
			
			String [] event = new String[1];
			event[0] = PROPERTY_APPLY_SUCCESS;
			
			notifyObservers(event);
		} else {
			String [] event = new String[2];
			event[0] = PROPERTY_APPLY_FAILURE;
			event[1] = msg;
			notifyObservers(event);
		}
	}
	
	public void notifyObservers(Object msg) {
           setChanged();
           super.notifyObservers(msg);
    }
	
	/** 
	 * Dispose the composite that holds the property page 
	 */
	public void dispose() {
		contentHolder.dispose();
	}
	
	protected abstract void initValues();
	
	public void updateI18N() {
		apply.setText(SolVE.i18n.getResourceString("APPLY"));
		propertyName.setText(SolVE.i18n.getResourceString("PROPERTY_NAME"));
	}
}
