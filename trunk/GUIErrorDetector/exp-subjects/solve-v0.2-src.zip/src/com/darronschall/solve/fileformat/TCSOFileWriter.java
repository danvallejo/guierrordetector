/*
 * Copyright Notice
 * 
 * (c) 2004 Darron Schall
 * http://solve.sourceforge.net
 * 
 * All rights reserved
 * 
 * 	This program and the accompanying materials are made available under
 *	the terms of the Common Public License v1.0 which accompanies this
 *	distribution, and is available at:  
 *			http://solve.sourceforge.net/cpl-v1.0.html
 *
 * This copyright notice MUST APPEAR in all copies of this file
 *
 * Contributors:
 *			Darron Schall - initial implementation
 */

package com.darronschall.solve.fileformat;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.RandomAccessFile;
import java.util.Iterator;

import com.darronschall.solve.datatypes.Array;
import com.darronschall.solve.datatypes.Boolean;
import com.darronschall.solve.datatypes.DataType;
import com.darronschall.solve.datatypes.Null;
import com.darronschall.solve.datatypes.Number;
import com.darronschall.solve.datatypes.Object;
import com.darronschall.solve.datatypes.String;
import com.darronschall.solve.datatypes.Types;
import com.darronschall.solve.datatypes.Undefined;
import com.darronschall.solve.gui.SolVE;
import com.darronschall.util.IntegerUtility;

/**
 * @author <a href="mailto:darron@darronschall.com>Darron Schall</a>
 * 
 * Provides a static write to write a local shared object from memory
 * to disk.
 */
public class TCSOFileWriter {

	/**
	 * Writes an Object datatype from memory to a file.
	 * 
	 * @param path	The path of the file to be written
	 * @param data	The Object to be written
	 * @throws Exception	An Exception indicating some sort of write error
	 */
	public static void write(java.lang.String path, Object data) throws Exception {
		File solFile;
		FileOutputStream out = null;
		RandomAccessFile out2 = null; // to re-writing header for correct length
		
		try {
			solFile = new File(path);
			if (!TCSOFile.isValidFile(solFile, false, true)) {
				return;
			}
			out = new FileOutputStream(solFile);
			
			int totalBytes = 0;
			
			writeHeader(out);
			totalBytes += writeFileType(out);
			totalBytes += writePad(out);
			totalBytes += writeName(out, data.getName());
			
			// write the data in our root object
			Iterator it = data.iterator();
			while (it.hasNext()) {
				DataType nested = (DataType)it.next();
				totalBytes += writeDataType(out, nested, false);			
			}			
			
			// when all is said and done, have to overwrite length
			// since we just filled 0's in the header
			out2 = new RandomAccessFile(solFile, "rw");
			writeLen(out2, totalBytes);
			
		} catch (Exception e) {
			throw e;
		} finally {
			if (out != null) try { out.close(); } catch (IOException e) { ; }
			if (out2 != null) try { out2.close(); } catch (IOException e) { ; }
		}
	}
	
	private static void writeHeader(OutputStream out) throws IOException {
		byte bytes[] = {0x00, (byte)0xBF, 0x00, 0x00, 0x00, 0x00};
		
		// last 4 bytes in the header are reserved for total length
		// and will get overwritten once we know how many bytes
		// there are in the file
		
		out.write(bytes);
	}
	
	private static void writeLen(RandomAccessFile out, int byteCount) throws IOException {
		out.seek(2L);
		out.write(IntegerUtility.toByteArray(byteCount));
	}
	
	private static int writeFileType(OutputStream out) throws IOException {
		out.write("TCSO".getBytes());
		return 4;
	}
	
	private static int writePad(OutputStream out) throws IOException {
		byte[] bytes = {0x00, 0x04, 0x00, 0x00, 0x00, 0x00};
		
		out.write(bytes);
		
		return bytes.length;
	}
	
	private static int writeName(OutputStream out, java.lang.String name) throws IOException {
		ByteArrayOutputStream bytes = new ByteArrayOutputStream();
		
		// first write 2 byte length
		bytes.write(IntegerUtility.toByteArray((short)name.getBytes("UTF8").length));
		// next write the name
		bytes.write(name.getBytes("UTF8"));
		// finally, add the padding - 4 bytes
		bytes.write(0x00);
		bytes.write(0x00);
		bytes.write(0x00);
		bytes.write(0x00);
				
		bytes.writeTo(out);
		
		return bytes.size();
	}
	
	private static int writeNumber(OutputStream out, Number n, boolean inObj) throws IOException {
		int totalBytes = 0;
		
		out.write(Types.NUMBER);
		totalBytes += 1;
		
		// write the actual number value - 8 bytes (double)
		out.write(IntegerUtility.toByteArray(Double.doubleToLongBits(n.getValue())));
		totalBytes += 8;
		
		// write the end marker, but only if the number is not nested in an object
		if (!inObj) { 
			out.write(0x00);
			totalBytes += 1;
		}
				
		return totalBytes;
	}
	
	private static int writeString(OutputStream out, String s, boolean inObj) throws IOException {
		int totalBytes = 0;
		
		out.write(Types.STRING);
		totalBytes += 1;
		
		// write the 2 byte length of the string
		out.write(IntegerUtility.toByteArray((short)s.getValue().getBytes("UTF8").length));
		totalBytes += 2;
		
		// write the actual string value
		out.write(s.getValue().getBytes("UTF8"));
		totalBytes += s.getValue().getBytes("UTF8").length;
		
		// write the end marker, but only if the number is not nested in an object
		if (!inObj) { 
			out.write(0x00);
			totalBytes += 1;
		}
		
		return totalBytes;
	}
	
	private static int writeObject(OutputStream out, Object data, boolean inObj) throws IOException {
		int totalBytes = 0;
		
		out.write(Types.OBJECT);
		totalBytes += 1;
		
		Iterator it = data.iterator();
		while (it.hasNext()) {
			DataType nested = (DataType)it.next();
			totalBytes += writeDataType(out, nested, true);			
		}
		
		byte endMarker[] = {0x00, 0x00, 0x09};
		out.write(endMarker);
		totalBytes += endMarker.length;
		
		// only write the last 0x00 if we're at the end of the object
		if (!inObj) {
			out.write(0x00);
			totalBytes += 1;
		}
		
		return totalBytes;
	}
	
	private static int writeArray(OutputStream out, Array data, boolean inObj) throws IOException {
		int totalBytes = 0;
		
		out.write(Types.ARRAY);
		totalBytes += 1;
		
		// only difference between array and object seems to be
		// the count?
		// TODO: fix me to use the line below instead of 
		// an iterator just to get the length
		// out.write(data.getLength());
		Iterator it4len = data.iterator();
		int length = 0;
		while (it4len.hasNext()) {
			length ++;
			it4len.next();
		}
		out.write(IntegerUtility.toByteArray(length));
		totalBytes += 4;
		
		Iterator it = data.iterator();
		while (it.hasNext()) {
			DataType nested = (DataType)it.next();
			totalBytes += writeDataType(out, nested, true);
		}
		
		byte endMarker[] = {0x00, 0x00, 0x09};
		out.write(endMarker);
		totalBytes += endMarker.length;
		
		// only write the last 0x00 if we're at the end of the object
		if (!inObj) {
			out.write(0x00);
			totalBytes += 1;
		}
		
		return totalBytes;
	}
	
	private static int writeBoolean(OutputStream out, Boolean data, boolean inObj) throws IOException {
		int totalBytes = 0;
		
		out.write(Types.BOOLEAN);
		totalBytes += 1;
		
		out.write(data.getValue() ? 0x01: 0x00);
		totalBytes += 1;
		
		// write the end marker, but only if the boolean is not nested in an object
		if (!inObj) { 
			out.write(0x00);
			totalBytes += 1;
		}
		
		return totalBytes;
	}
	
	private static int writeNull(OutputStream out, Null data, boolean inObj) throws IOException {
		int totalBytes = 0;
		
		out.write(Types.NULL);
		totalBytes += 1;
		
		out.write(0x00);
		totalBytes += 1;
		
		// write the end marker, but only if not nested in an object
		if (!inObj) { 
			out.write(0x00);
			totalBytes += 1;
		}
		
		return totalBytes;
	}
	
	private static int writeUndefined(OutputStream out, Undefined data, boolean inObj) throws IOException {
		int totalBytes = 0;
		
		out.write(Types.UNDEFINED);
		totalBytes += 1;
		
		out.write(0x00);
		totalBytes += 1;
		
		// write the end marker, but only if not nested in an object
		if (!inObj) { 
			out.write(0x00);
			totalBytes += 1;
		}
		
		return totalBytes;
	}
	
	private static int writeDataType(OutputStream out, DataType data, boolean inObj) throws IOException {
		
		int totalBytes = 0;
		
		// first write the variable name of the data type
		ByteArrayOutputStream bytes = new ByteArrayOutputStream();
		java.lang.String name = data.getName();
		
		// first write the 2 byte length
		bytes.write(IntegerUtility.toByteArray((short)name.getBytes("UTF8").length));
		// write the name
		bytes.write(name.getBytes("UTF8"));
		
		bytes.writeTo(out);
		
		totalBytes = bytes.size();
		
		java.lang.String className = data.getClass().getName();
		className = className.substring(className.lastIndexOf(".")+1);
		
		// TODO: this code can probably be improved upon
		if (className.equals("Number")) {
			//System.out.println("found number: " + data.getName());
			return totalBytes + writeNumber(out, (Number)data, inObj);
		} else if (className.equals("String")) {
			//System.out.println("found string: " + data.getName());
			return totalBytes + writeString(out, (String)data, inObj);
		} else if (className.equals("Object")) {
			//System.out.println("found object: " + data.getName());
			return totalBytes + writeObject(out, (Object)data, inObj);
		} else if (className.equals("Boolean")) {
			return totalBytes += writeBoolean(out, (Boolean)data, inObj);
		} else if (className.equals("Null")) {
			return totalBytes += writeNull(out, (Null)data, inObj);
		} else if (className.equals("Undefined")) {
			return totalBytes += writeUndefined(out, (Undefined)data, inObj);
		} else if (className.equals("Array")) {
			return totalBytes += writeArray(out, (Array)data, inObj);
		}
		
		throw new IOException(className + " " + SolVE.i18n.getResourceString("INVALID_DATA_TYPE"));
		
	}
	
	private TCSOFileWriter() {
		// protect from instantiation
	}
	
}
