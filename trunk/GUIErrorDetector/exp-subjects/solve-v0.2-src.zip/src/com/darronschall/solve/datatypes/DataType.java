/*
 * Copyright Notice
 * 
 * (c) 2004 Darron Schall
 * http://solve.sourceforge.net
 * 
 * All rights reserved
 * 
 * 	This program and the accompanying materials are made available under
 *	the terms of the Common Public License v1.0 which accompanies this
 *	distribution, and is available at:  
 *			http://solve.sourceforge.net/cpl-v1.0.html
 *
 * This copyright notice MUST APPEAR in all copies of this file
 *
 * Contributors:
 *			Darron Schall - initial implementation
 */

package com.darronschall.solve.datatypes;

// TRICKY: We need to import the java String type because
// there is a String datatype in this package
import java.lang.String;

/**
 * @author <a href="mailto:darron@darronschall.com>Darron Schall</a>
 * 
 * DataType is the base class for all of the types found in a 
 * local shared object file.  It provides methods to set and 
 * retrieve the "name" of the type, which correlates to the
 * variable name of the type.
 */
public class DataType {
	
	protected String name;  // the "variable name"
	
	/**
	 * @param name	The "variable name" of the DataType
	 */
	public DataType(String name) {
		this.setName(name);
	}
	
	/**
	 * @return The "variable name" of the DataType
	 */
	public String getName() {
		return this.name;
	}
	
	/**
	 * @param name	The "variable name" of the DataType
	 */
	public void setName(String name) {
		this.name = name;
	}
}
