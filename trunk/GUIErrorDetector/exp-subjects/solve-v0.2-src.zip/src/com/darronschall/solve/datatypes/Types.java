/*
 * Copyright Notice
 * 
 * (c) 2004 Darron Schall
 * http://solve.sourceforge.net
 * 
 * All rights reserved
 * 
 * 	This program and the accompanying materials are made available under
 *	the terms of the Common Public License v1.0 which accompanies this
 *	distribution, and is available at:  
 *			http://solve.sourceforge.net/cpl-v1.0.html
 *
 * This copyright notice MUST APPEAR in all copies of this file
 *
 * Contributors:
 *			Darron Schall - initial implementation
 */

package com.darronschall.solve.datatypes;

/**
 * @author <a href="mailto:darron@darronschall.com>Darron Schall</a>
 * 
 * Types is somewhat of an enumerated type for the different DataTypes
 * available in a local shared object file.  Each DataType has a constant
 * integer value that corresponds to the type value of the DataType
 * in the file.  This is somewhat bad - in case the file format ever
 * changes this class will need to be updated to support the new file 
 * type.  In reality, this should most likely be moved to the fileformat
 * package, and there should be a Types version for each fileformat if
 * in the future there is more than one fileformat.
 * 
 * Additionally, the Type constants are used to determine what kind of
 * datatype was clicked on in the DataTreePopup.
 */
public final class Types {
	
	public static final int NUMBER = 0x0;
	public static final int BOOLEAN = 0x1;
	public static final int STRING = 0x2;
	public static final int OBJECT = 0x3;
	public static final int NULL = 0x5;
	public static final int UNDEFINED = 0x6;
	public static final int ARRAY = 0x8;
	public static final int DATE = 0xB;
	public static final int XML = 0xF;
	public static final int CLASS = 0x10;
	
	private Types() {
		// protect from instantiation
	}
}
