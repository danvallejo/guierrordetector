/*
 * Copyright Notice
 * 
 * (c) 2004 Darron Schall
 * http://solve.sourceforge.net
 * 
 * All rights reserved
 * 
 * 	This program and the accompanying materials are made available under
 *	the terms of the Common Public License v1.0 which accompanies this
 *	distribution, and is available at:  
 *			http://solve.sourceforge.net/cpl-v1.0.html
 *
 * This copyright notice MUST APPEAR in all copies of this file
 *
 * Contributors:
 *			Darron Schall - initial implementation
 */

package com.darronschall.solve.gui;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.PaintEvent;
import org.eclipse.swt.events.PaintListener;
import org.eclipse.swt.widgets.Shell;

import com.darronschall.util.LayoutUtility;

/**
 * @author <a href="mailto:darron@darronschall.com>Darron Schall</a>
 */
public class Splash {
	
	private Shell parentShell;
	private Shell shell;
	
	public Splash(Shell parentShell) {
		this.parentShell = parentShell;
		this.shell = new Shell(parentShell, SWT.NONE | SWT.ON_TOP);
		
		this.shell.setSize(300, 230);
		LayoutUtility.centerShell(this.shell);
		
		this.shell.addPaintListener(new PaintListener() {
			public void paintControl(PaintEvent e) {
				//Image splashImage = new Image(e.display, getResourceAsStream(...));
				//e.gc.drawImage(splashImage, 0, 0);
				//splashImage.dispose();
			}
		});
	}
	
	public void open() {
		shell.open();
	}
	
	public void dispose() {
		shell.dispose();
	}
}
