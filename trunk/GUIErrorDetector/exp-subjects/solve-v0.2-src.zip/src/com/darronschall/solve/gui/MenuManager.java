/*
 * Copyright Notice
 * 
 * (c) 2004 Darron Schall
 * http://solve.sourceforge.net
 * 
 * All rights reserved
 * 
 * 	This program and the accompanying materials are made available under
 *	the terms of the Common Public License v1.0 which accompanies this
 *	distribution, and is available at:  
 *			http://solve.sourceforge.net/cpl-v1.0.html
 *
 * This copyright notice MUST APPEAR in all copies of this file
 *
 * Contributors:
 *			Darron Schall - initial implementation
 */

package com.darronschall.solve.gui;

import org.eclipse.swt.widgets.MenuItem;

/**
 * @author <a href="mailto:darron@darronschall.com>Darron Schall</a>
 */
class MenuManager {

	private static MenuItem closeItem;

	private static MenuItem saveItem;

	private static MenuItem saveAsItem;

	public static final int NO_FILE_OPEN = 0;

	public static final int FILE_OPENED = 1;

	public static final int DATA_MODIFIED = 2;

	public static final int NEW_DATA_MODIFIED = 3;

	public static final int FILE_SAVED = 4;

	private MenuManager() {
		// protect class from being instantiated
	}

	static void registerCloseItem(MenuItem closeItem) {
		MenuManager.closeItem = closeItem;
	}

	static void registerSaveItems(MenuItem saveItem, MenuItem saveAsItem) {
		MenuManager.saveItem = saveItem;
		MenuManager.saveAsItem = saveAsItem;
	}

	static void setNewState(int state) {
		switch (state) {
		case NO_FILE_OPEN:
			closeItem.setEnabled(false);
			saveItem.setEnabled(false);
			saveAsItem.setEnabled(false);
			break;

		case FILE_OPENED:
			closeItem.setEnabled(true);
			saveAsItem.setEnabled(true);
			break;

		case DATA_MODIFIED:
			saveItem.setEnabled(true);
			saveAsItem.setEnabled(true);
			break;

		case NEW_DATA_MODIFIED:
			saveAsItem.setEnabled(true);
			break;

		case FILE_SAVED:
			closeItem.setEnabled(true);
			saveItem.setEnabled(false);
			saveAsItem.setEnabled(true);
			break;

		}
	}
}