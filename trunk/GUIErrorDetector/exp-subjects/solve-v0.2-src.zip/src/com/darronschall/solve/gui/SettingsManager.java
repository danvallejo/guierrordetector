/*
 * Copyright Notice
 * 
 * (c) 2004 Darron Schall
 * http://solve.sourceforge.net
 * 
 * All rights reserved
 * 
 * 	This program and the accompanying materials are made available under
 *	the terms of the Common Public License v1.0 which accompanies this
 *	distribution, and is available at:  
 *			http://solve.sourceforge.net/cpl-v1.0.html
 *
 * This copyright notice MUST APPEAR in all copies of this file
 *
 * Contributors:
 *			Darron Schall - initial implementation
 */

package com.darronschall.solve.gui;

import java.util.Hashtable;

import org.eclipse.swt.SWT;

/**
 * @author <a href="mailto:darron@darronschall.com">Darron Schall</a>
 */
public class SettingsManager {
	
	public static final boolean isMac = SWT.getPlatform().equalsIgnoreCase("carbon");
	
	public static final boolean isLinux = SWT.getPlatform().equalsIgnoreCase("gtk");
	
	public static final boolean isWindows = SWT.getPlatform().equalsIgnoreCase("win32");
	
	public static final boolean isSolaris = SWT.getPlatform().equalsIgnoreCase("motif");
	
	public static boolean askSaveOnExit = true;
	
	public static boolean showSplashOnStart = false;
	
	public static Hashtable hotKeys = new Hashtable();
	
	// OS dependant File separator
	//public static String PATH_SEPARATOR = System.getProperty("file.separator");
	
	private SettingsManager() {
		// protect class from being instantiated
	}
	
	public static void initDefaultAccelerators() {
		String labelStr;
		int swtConstant;
		
		if (isMac) {
			labelStr = SolVE.i18n.getResourceString("LABEL_KEY_COMMAND");
			swtConstant = SWT.COMMAND;
		} else {
			labelStr = SolVE.i18n.getResourceString("LABEL_KEY_CONTROL");
			swtConstant = SWT.CONTROL;
		}
		
		hotKeys.put("MENU_NEW", new String[] { labelStr + "+N", String.valueOf(swtConstant | 'n') });
		hotKeys.put("MENU_OPEN", new String[] { labelStr + "+O", String.valueOf(swtConstant | 'o') });
		hotKeys.put("MENU_OPEN_PLAYER", new String[] { labelStr + "+P", String.valueOf(swtConstant | 'p')});
		hotKeys.put("MENU_CLOSE", new String[] { labelStr + "+W", String.valueOf(swtConstant | 'w') });
		hotKeys.put("MENU_SAVE", new String[] { labelStr + "+S", String.valueOf(swtConstant | 's') });
		hotKeys.put("MENU_EXIT", new String[] { labelStr + "+X", String.valueOf(swtConstant | 'x') });
	}
	
	public static String getPlayerPath() {
		String path = "";
		String userHome = System.getProperty("user.home");
		
		if (isMac) {
			// path on Mac: /Users/[username]/Library/Preferences/
			//   Macromedia/Flash Player
			path = userHome + "/Library/Preferences/Macromedia/Flash Player";
		} else if (isWindows) {
			path = userHome + "/" + SolVE.i18n.getResourceString("APPLICATION_DATA") 
						+ "Macromedia/Flash Player";
		}
		
		return path;
	}
}
