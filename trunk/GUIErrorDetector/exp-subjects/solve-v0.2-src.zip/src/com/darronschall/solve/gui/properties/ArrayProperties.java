/*
 * Copyright Notice
 * 
 * (c) 2004 Darron Schall
 * http://solve.sourceforge.net
 * 
 * All rights reserved
 * 
 * 	This program and the accompanying materials are made available under
 *	the terms of the Common Public License v1.0 which accompanies this
 *	distribution, and is available at:  
 *			http://solve.sourceforge.net/cpl-v1.0.html
 *
 * This copyright notice MUST APPEAR in all copies of this file
 *
 * Contributors:
 *			Darron Schall - initial implementation
 */

package com.darronschall.solve.gui.properties;

import org.eclipse.swt.widgets.Composite;

import com.darronschall.solve.datatypes.Array;

/**
 * @author <a href="mailto:darron@darronschall.com>Darron Schall</a>
 */
public class ArrayProperties extends PropertyPage {

	Array array;
	
	public ArrayProperties(Composite parent, Array array) {
		super(parent);
		this.array = array;
		
		initValues();
		updateI18N();
	}
	
	protected void initValues() {
		nameValue.setText(array.getName());
		
		initialValuesSet = true;
	}
	
	public void applyButtonPressed() {
		// TODO: String msg = validate(); - make sure
		// index is valid, but hard to do because
		// arrays are regular object as well and not
		// every property in an array has to be 
		// indexed
		
		array.setName(nameValue.getText());
			
		super.applyButtonPressed();	
	}
}
