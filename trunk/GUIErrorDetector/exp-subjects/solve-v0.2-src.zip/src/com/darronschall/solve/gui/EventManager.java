/*
 * Copyright Notice
 * 
 * (c) 2004 Darron Schall
 * http://solve.sourceforge.net
 * 
 * All rights reserved
 * 
 * 	This program and the accompanying materials are made available under
 *	the terms of the Common Public License v1.0 which accompanies this
 *	distribution, and is available at:  
 *			http://solve.sourceforge.net/cpl-v1.0.html
 *
 * This copyright notice MUST APPEAR in all copies of this file
 *
 * Contributors:
 *			Darron Schall - initial implementation
 */

package com.darronschall.solve.gui;

import java.util.Observable;
import java.util.Observer;

import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.FileDialog;
import org.eclipse.swt.widgets.MenuItem;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.TreeItem;

import com.darronschall.solve.datatypes.Array;
import com.darronschall.solve.datatypes.Boolean;
import com.darronschall.solve.datatypes.ContainerType;
import com.darronschall.solve.datatypes.DataType;
import com.darronschall.solve.datatypes.Null;
import com.darronschall.solve.datatypes.Number;
import com.darronschall.solve.datatypes.Object;
import com.darronschall.solve.datatypes.String;
import com.darronschall.solve.datatypes.Types;
import com.darronschall.solve.datatypes.Undefined;
import com.darronschall.solve.fileformat.TCSOFileReader;
import com.darronschall.solve.fileformat.TCSOFileWriter;
import com.darronschall.solve.gui.dialogs.AboutDialog;
import com.darronschall.solve.gui.properties.PropertyPage;

/**
 * @author <a href="mailto:darron@darronschall.com>Darron Schall</a>
 */
public class EventManager implements Observer {

	private Shell shell;

	private SolVE gui;

	private java.lang.String file;

	/**
	 * Instantiate a new EventManager
	 * 
	 * @param shell
	 *            The shell
	 * @param gui
	 *            The main controller
	 */
	public EventManager(Shell shell, SolVE gui) {
		this.shell = shell;
		this.gui = gui;
	}

	public void actionOpenFile() {
		actionOpenFile(false);
	}

	public void actionOpenFile(boolean fromPlayerFolder) {
		if (gui.isDirty()) {
			if (gui.askSaveChanges(SolVE.ASK_BEFORE_OPEN)) {
				if (file == null) {
					actionSaveFileAs();
				} else {
					actionSaveFile();
				}
			}
		}

		java.lang.String extensions[] = { SolVE.i18n.getResourceString("SOL_FILTER_EXT") };
		java.lang.String names[] = { SolVE.i18n.getResourceString("SOL_FILTER_NAME") };

		FileDialog fileDialog = new FileDialog(this.shell);
		fileDialog.setFilterExtensions(extensions);
		fileDialog.setFilterNames(names);
		fileDialog.setText(SolVE.i18n.getResourceString("OPEN_FILE_TITLE"));

		if (fromPlayerFolder) {
			fileDialog.setFilterPath(SettingsManager.getPlayerPath());
		}

		java.lang.String file = fileDialog.open();

		if (file != null) {
			this.file = file;

			try {
				MenuManager.setNewState(MenuManager.FILE_OPENED);
				gui.getDataTree().setDataObject(TCSOFileReader.read(file));
				gui.getPropertyPane().reset();

				gui.setStatusText(file.toString());
				gui.setDirty(false);
			} catch (Exception e) {
				MessageDialog.openError(gui.getShell(), SolVE.i18n.getResourceString("ERROR"), e.getMessage());
				System.out.println("c: " + e.getCause());
				e.printStackTrace();
				System.out.println("m: " + e.getLocalizedMessage());
			}

		}
	}

	public boolean actionSaveFile() {
		try {
			TCSOFileWriter.write(file, gui.getDataTree().getDataObject());
		} catch (Exception e) {
			MessageDialog.openError(gui.getShell(), SolVE.i18n.getResourceString("SAVE_ERROR"), e.getMessage());
			return false;
		}

		MenuManager.setNewState(MenuManager.FILE_SAVED);
		gui.setDirty(false);
		return true;
	}

	public void actionSaveFileAs() {
		java.lang.String extensions[] = { SolVE.i18n.getResourceString("SOL_FILTER_EXT") };
		java.lang.String names[] = { SolVE.i18n.getResourceString("SOL_FILTER_NAME") };

		FileDialog fileDialog = new FileDialog(this.shell, SWT.SAVE);
		fileDialog.setFilterExtensions(extensions);
		fileDialog.setFilterNames(names);

		java.lang.String file = fileDialog.open();

		if (file != null) {
			// TODO: check if file exists and ask overwrite - OS X does 
			// this automatically, so we only need to do this on Windows

			this.file = file;
			if (actionSaveFile()) {
				gui.setStatusText(file);
			}
		}
	}

	public void actionNew() {
		if (gui.isDirty()) {
			if (gui.askSaveChanges(SolVE.ASK_BEFORE_NEW)) {
				if (file == null) {
					actionSaveFileAs();
				} else {
					actionSaveFile();
				}
			}
		}

		file = null;

		gui.getPropertyPane().reset();
		MenuManager.setNewState(MenuManager.NEW_DATA_MODIFIED);
		gui.getDataTree().setDataObject(new Object(SolVE.i18n.getResourceString("UNNAMED")));
		gui.setStatusText("");
		gui.setDirty(true);
	}

	public void actionClose() {
		if (gui.isDirty()) {
			if (gui.askSaveChanges(SolVE.ASK_BEFORE_CLOSE)) {
				if (file == null) {
					actionSaveFileAs();
				} else {
					actionSaveFile();
				}
			}
		}

		MenuManager.setNewState(MenuManager.NO_FILE_OPEN);

		gui.getDataTree().empty();
		gui.getPropertyPane().reset();

		gui.setStatusText("");
		gui.setDirty(false);
	}

	/**
	 * Show the about dialog
	 */
	public void actionOpenAbout() {
		new AboutDialog(this.shell).open();
	}

	/**
	 * Exit application
	 */
	public void actionExit() {
		shell.notifyListeners(SWT.Close, new Event());

		// Only dispose if the we're closing the application
		if (SolVE.isClosing)
			this.shell.getDisplay().dispose();
	}

	public void actionTreeItemSelected() {

		DataType selectedItem = gui.getDataTree().getSelectedData();

		if (selectedItem instanceof Array) {
			gui.getPropertyPane().createArrayProperties((Array) selectedItem);			
		} else if (selectedItem instanceof Object) {
			gui.getPropertyPane().createObjectProperties((Object) selectedItem);
		} else if (selectedItem instanceof Number) {
			gui.getPropertyPane().createNumberProperties((Number) selectedItem);
		} else if (selectedItem instanceof String) {
			gui.getPropertyPane().createStringProperties((String) selectedItem);
		} else if (selectedItem instanceof Boolean) {
			gui.getPropertyPane().createBooleanProperties((Boolean) selectedItem);
		} else if (selectedItem instanceof Null) {
			gui.getPropertyPane().createNullProperties((Null) selectedItem);
		} else if (selectedItem instanceof Undefined) {
			gui.getPropertyPane().createUndefinedProperties((Undefined) selectedItem);
		}
		// TODO: build out with more data types

		// Configure / show the popup menu
		gui.getDataTree().configurePopupMenu();
	}

	public void actionInsertDataType(int type) {
		DataType data = null;
		ContainerType selectedContainer = (ContainerType) gui.getDataTree().getSelectedData();
		java.lang.String sNewItem = SolVE.i18n.getResourceString("NEW_ITEM");
		
		// make sure new property name isn't the same
		// as another property name in the selected Item's parent
		Integer i = new Integer(0);
		while (selectedContainer.contains(sNewItem)) {
			if (i.intValue() > 0) {
				sNewItem = sNewItem.substring(0, sNewItem.length() - i.toString().length());
			}
			i = new Integer(i.intValue() + 1);
			sNewItem = sNewItem + i;
		}
		
		switch (type) {
		case Types.NUMBER:
			data = new Number(sNewItem, 0);
			break;

		case Types.BOOLEAN:
			data = new Boolean(sNewItem, false);
			break;

		case Types.STRING:
			data = new String(sNewItem, "");
			break;

		case Types.OBJECT:
			data = new Object(sNewItem);
			break;

		case Types.NULL:
			data = new Null(sNewItem);
			break;

		case Types.UNDEFINED:
			data = new Undefined(sNewItem);
			break;
			
		case Types.ARRAY:
			data = new Array(sNewItem);
			break;
		}

		selectedContainer.add(data);

		// refresh the tree so the added item displays
		TreeItem newItem = new TreeItem(gui.getDataTree().getSelectedItem(), SWT.NONE);
		newItem.setData(data);
		gui.getDataTree().updateLabel(newItem);
		gui.getDataTree().getSelectedItem().setExpanded(true);

		// update the gui to be dirty since something changed
		if (file == null) {
			MenuManager.setNewState(MenuManager.NEW_DATA_MODIFIED);
		} else {
			MenuManager.setNewState(MenuManager.DATA_MODIFIED);
		}
		gui.setDirty(true);
	}

	public void actionDeleteFromTree() {
		// prevent deletion of the root node
		TreeItem selectedParentItem = gui.getDataTree().getSelectedItem().getParentItem();
		if (selectedParentItem == null) {
			//System.out.println("cannot delete root node");
			return;
		}

		// delete the node from the model
		DataType selectedItem = (DataType) gui.getDataTree().getSelectedData();
		((ContainerType) selectedParentItem.getData()).remove(selectedItem);
		// remove node from the tree
		gui.getDataTree().getSelectedItem().dispose();
		// make sure the parent of the selected node is focused
		selectedParentItem.getParent().setSelection(
				new TreeItem[] { selectedParentItem });
		actionTreeItemSelected();

		// update the gui to be dirty since something changed
		if (file == null) {
			MenuManager.setNewState(MenuManager.NEW_DATA_MODIFIED);
		} else {
			MenuManager.setNewState(MenuManager.DATA_MODIFIED);
		}
		gui.setDirty(true);
	}

	public void actionSelectLanguage(SelectionEvent se) {
		// only update i18n for the selection event where the
		// radio button is selected, not deselected
		if (((MenuItem)se.getSource()).getSelection()) {
			SolVE.i18n.setLocale((java.lang.String)(((MenuItem)se.getSource()).getData()));
			
			gui.updateI18N();	
		}
	}
	
	public void update(Observable o, java.lang.Object msg) {
		if (((java.lang.String []) (msg))[0]
				.equals(PropertyPage.PROPERTY_APPLY_SUCCESS)) {

			// TODO: make sure new property name isn't the same
			// as another property name in the selected Item's parent
			gui.getDataTree().updateLabel(gui.getDataTree().getSelectedItem());

			if (file == null) {
				MenuManager.setNewState(MenuManager.NEW_DATA_MODIFIED);
			} else {
				MenuManager.setNewState(MenuManager.DATA_MODIFIED);
			}
			gui.setDirty(true);
		} else if (((java.lang.String []) (msg))[0]
				.equals(PropertyPage.PROPERTY_APPLY_FAILURE)) {

			MessageDialog.openError(gui.getShell(), SolVE.i18n.getResourceString("VALIDATION_ERROR"),
					((java.lang.String []) (msg))[1]);
		}
	}

	public java.lang.String getFile() {
		return file;
	}
}