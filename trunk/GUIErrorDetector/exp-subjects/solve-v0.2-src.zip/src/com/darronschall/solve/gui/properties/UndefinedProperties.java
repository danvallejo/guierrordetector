/*
 * Copyright Notice
 * 
 * (c) 2004 Darron Schall
 * http://solve.sourceforge.net
 * 
 * All rights reserved
 * 
 * 	This program and the accompanying materials are made available under
 *	the terms of the Common Public License v1.0 which accompanies this
 *	distribution, and is available at:  
 *			http://solve.sourceforge.net/cpl-v1.0.html
 *
 * This copyright notice MUST APPEAR in all copies of this file
 *
 * Contributors:
 *			Darron Schall - initial implementation
 */

package com.darronschall.solve.gui.properties;

import org.eclipse.swt.widgets.Composite;

import com.darronschall.solve.datatypes.Undefined;

/**
 * @author <a href="mailto:darron@darronschall.com>Darron Schall</a>
 */
public class UndefinedProperties extends PropertyPage {

	Undefined u;
	
	public UndefinedProperties(Composite parent, Undefined u) {
		super(parent);
		this.u = u;
		
		initValues();
	}
	
	protected void initValues() {
		nameValue.setText(u.getName());
		
		initialValuesSet = true;
	}
	
	public void applyButtonPressed() {
		u.setName(nameValue.getText());
			
		super.applyButtonPressed();	
	}
}
