/*
 * Copyright Notice
 * 
 * (c) 2004 Darron Schall
 * http://solve.sourceforge.net
 * 
 * All rights reserved
 * 
 * 	This program and the accompanying materials are made available under
 *	the terms of the Common Public License v1.0 which accompanies this
 *	distribution, and is available at:  
 *			http://solve.sourceforge.net/cpl-v1.0.html
 *
 * This copyright notice MUST APPEAR in all copies of this file
 *
 * Contributors:
 *			Darron Schall - initial implementation
 */

package com.darronschall.solve.gui;

import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.layout.FormAttachment;
import org.eclipse.swt.layout.FormData;
import org.eclipse.swt.layout.FormLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;

import com.darronschall.solve.datatypes.Array;
import com.darronschall.solve.datatypes.Boolean;
import com.darronschall.solve.datatypes.Null;
import com.darronschall.solve.datatypes.Number;
import com.darronschall.solve.datatypes.Object;
import com.darronschall.solve.datatypes.String;
import com.darronschall.solve.datatypes.Undefined;
import com.darronschall.solve.gui.properties.ArrayProperties;
import com.darronschall.solve.gui.properties.BooleanProperties;
import com.darronschall.solve.gui.properties.NullProperties;
import com.darronschall.solve.gui.properties.NumberProperties;
import com.darronschall.solve.gui.properties.ObjectProperties;
import com.darronschall.solve.gui.properties.PropertyPage;
import com.darronschall.solve.gui.properties.StringProperties;
import com.darronschall.solve.gui.properties.UndefinedProperties;
import com.darronschall.util.FontUtility;
import com.darronschall.util.LayoutUtility;

/**
 * @author <a href="mailto:darron@darronschall.com>Darron Schall</a>
 */
public class PropertyPane {

	private Composite parent;
	
	// The "master" composite that holds either the properties
	// or the default composite.  This is needed because when we 
	// create/destroy the properties/defaults, the layout of the
	// parent gets reset, so by keeping a master in tact at all
	// times we avoid those issues.
	private Composite pane = null;

	private SolVE gui;
	
	private EventManager eventManager;

	private Composite propertiesHolder = null;

	private Composite propertiesTitleHolder = null;
	
	private Label propertiesTitle = null;

	private Composite propertiesContent = null;
	
	private PropertyPage activePropertyPage = null;
	
	private Composite defaultHolder = null;
	
	private Label defaultLabel;

	/**
	 * Instantiate a new DataTree
	 */
	public PropertyPane(Composite parent, SolVE gui) {
		this.parent = parent;
		this.gui = gui;
		this.eventManager = gui.getEventManager();
		
		initComponents();
	}

	/** Create the default content to be displayed when no file is open */
	public void initComponents() {
		if (pane == null) {
			pane = new Composite(parent, SWT.NONE);
			FormLayout fl = new FormLayout();
			fl.marginWidth = 2;
			fl.marginHeight = 5;
			pane.setLayout(fl);
		}
				
		if (defaultHolder == null || defaultHolder.isDisposed()) { 
			defaultHolder = new Composite(pane, SWT.NONE);
			defaultHolder.setLayout(new FillLayout());
			FormData fd = new FormData();
			fd.left = new FormAttachment(0,0);
			fd.top = new FormAttachment(0, 0);
			fd.right = new FormAttachment(100, -3);
			fd.bottom = new FormAttachment(100, 0);
			defaultHolder.setLayoutData(fd);
			
			
			defaultLabel = new Label(defaultHolder, SWT.WRAP);
			updateI18N();
		}
		
		pane.layout();
	}

	public void createObjectProperties(Object obj) {
		renewPropertiesPage(SolVE.i18n.getResourceString("OBJECT_LABEL"));
		
		activePropertyPage = new ObjectProperties(propertiesContent, obj);
		activePropertyPage.addObserver(eventManager);
				
		propertiesContent.layout();
		pane.layout();
	}
	
	public void createNumberProperties(Number num) {
		renewPropertiesPage(SolVE.i18n.getResourceString("NUMBER_LABEL"));
		
		activePropertyPage = new NumberProperties(propertiesContent, num);
		activePropertyPage.addObserver(eventManager);
				
		propertiesContent.layout();
		pane.layout();
	}
	
	public void createStringProperties(String str) {
		renewPropertiesPage(SolVE.i18n.getResourceString("STRING_LABEL"));
		
		activePropertyPage = new StringProperties(propertiesContent, str);
		activePropertyPage.addObserver(eventManager);
				
		propertiesContent.layout();
		pane.layout();
	}
	
	public void createBooleanProperties(Boolean bool) {
		renewPropertiesPage(SolVE.i18n.getResourceString("BOOLEAN_LABEL"));
		
		activePropertyPage = new BooleanProperties(propertiesContent, bool);
		activePropertyPage.addObserver(eventManager);
		
		propertiesContent.layout();
		pane.layout();
	}
	
	public void createNullProperties(Null n) {
		renewPropertiesPage(SolVE.i18n.getResourceString("NULL_LABEL"));
		
		activePropertyPage = new NullProperties(propertiesContent, n);
		activePropertyPage.addObserver(eventManager);
		
		propertiesContent.layout();
		pane.layout();
	}
	
	public void createUndefinedProperties(Undefined u) {
		renewPropertiesPage(SolVE.i18n.getResourceString("UNDEFINED_LABEL"));
		
		activePropertyPage = new UndefinedProperties(propertiesContent, u);
		activePropertyPage.addObserver(eventManager);
		
		propertiesContent.layout();
		pane.layout();
	}
	
	public void createArrayProperties(Array a) {
		// TODO: i18n
		renewPropertiesPage("Array");
		
		activePropertyPage = new ArrayProperties(propertiesContent, a);
		activePropertyPage.addObserver(eventManager);
		
		propertiesContent.layout();
		pane.layout();
	}
	
	public void renewPropertiesPage(java.lang.String title) {
		// When we create the property page, we need to remove the
		// default content if it exists
		if (defaultHolder != null) {
			defaultHolder.dispose();
		}
		
		if (activePropertyPage != null) {
			activePropertyPage.deleteObserver(eventManager);
			activePropertyPage.dispose();
		}
		
		if (propertiesHolder == null || propertiesHolder.isDisposed()) {
			propertiesHolder = new Composite(pane, SWT.NONE);
			propertiesHolder.setLayout(LayoutUtility.createFormLayout(0, 0));
			
			FormData fd = new FormData();
			fd.left = new FormAttachment(0,0);
			fd.top = new FormAttachment(0, 0);
			fd.right = new FormAttachment(100, -3);
			fd.bottom = new FormAttachment(100, 0);
			propertiesHolder.setLayoutData(fd);
		}
		
		if (propertiesTitleHolder == null || propertiesTitleHolder.isDisposed()) {
			propertiesTitleHolder = new Composite(propertiesHolder, SWT.BORDER);
			propertiesTitleHolder.setBackground(gui.getShell().getDisplay()
					.getSystemColor(SWT.COLOR_WHITE));
			
			FormData fd = new FormData();
			fd.left = new FormAttachment(0, 0);
			fd.top = new FormAttachment(0, 0);
			fd.right = new FormAttachment(100, 0);
			propertiesTitleHolder.setLayoutData(fd);
						
			propertiesTitleHolder.setLayout(LayoutUtility.createFillLayout(3, 3));
		}
		
		if (propertiesTitle == null || propertiesTitle.isDisposed()) {
			propertiesTitle = new Label(propertiesTitleHolder, SWT.LEFT | SWT.NONE);
			propertiesTitle.setBackground(gui.getShell().getDisplay()
					.getSystemColor(SWT.COLOR_WHITE));
			propertiesTitle.setFont(FontUtility.headerFont);
		}
		
		if (propertiesContent == null || propertiesContent.isDisposed()) {
			propertiesContent = new Composite(propertiesHolder, SWT.NONE);
			FormData fd = new FormData();
			fd.left = new FormAttachment(0,0);
			fd.top = new FormAttachment(propertiesTitleHolder, 5);
			fd.right = new FormAttachment(100, 0);
			fd.bottom = new FormAttachment(100, 0);
			propertiesContent.setLayoutData(fd);
			propertiesContent.setLayout(LayoutUtility.createFormLayout(0, 0));
		}
		
		propertiesTitle.setText(title);
	}
	
	/** Clear out the property page and revert to default */
	public void reset() {
		if (propertiesHolder != null) {
			propertiesHolder.dispose();
			
			initComponents();	
		}
	}
	
	public void updateI18N() {
		if (activePropertyPage != null) {
			//activePropertyPage.updateI18N();
			// Instead of updating the string, just "click" the
			// tree item.  This has the side effect of 
			// erasing any data that hasn't been "applied"
			eventManager.actionTreeItemSelected();
		} else {
			defaultLabel.setText(SolVE.i18n.getResourceString("SUPPORTED_TYPES"));
		}
	}
}
		