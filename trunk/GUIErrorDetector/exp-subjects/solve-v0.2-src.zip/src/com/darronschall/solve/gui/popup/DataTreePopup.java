/*
 * Copyright Notice
 * 
 * (c) 2004 Darron Schall
 * http://solve.sourceforge.net
 * 
 * All rights reserved
 * 
 * 	This program and the accompanying materials are made available under
 *	the terms of the Common Public License v1.0 which accompanies this
 *	distribution, and is available at:  
 *			http://solve.sourceforge.net/cpl-v1.0.html
 *
 * This copyright notice MUST APPEAR in all copies of this file
 *
 * Contributors:
 *			Darron Schall - initial implementation
 */

package com.darronschall.solve.gui.popup;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.widgets.Menu;
import org.eclipse.swt.widgets.MenuItem;

import com.darronschall.solve.datatypes.Types;
import com.darronschall.solve.gui.SolVE;

/**
 * @author <a href="mailto:darron@darronschall.com>Darron Schall</a>
 */
public class DataTreePopup {
	
	public static final int CONTAINER_MENU = 0;
	
	public static final int NON_CONTAINER_MENU = 1;
	
	public static final int EMPTY_MENU = 2;
	
	public static final int ROOT_MENU = 3;
	
	private Menu treePopupMenu;
	private MenuItem addItem;
	private Menu addMenu;
	private MenuItem numberItem;
	private MenuItem booleanItem;
	private MenuItem stringItem;
	private MenuItem objectItem;
	private MenuItem nullItem;
	private MenuItem undefinedItem;
	private MenuItem arrayItem;
	private MenuItem deleteItem;
	
	private SolVE gui;
	
	public DataTreePopup(SolVE gui) {
		this.gui = gui;
		initComponents();
	}
	
	public void initComponents() {
		treePopupMenu = new Menu(gui.getShell(), SWT.POP_UP);
		
		addItem = new MenuItem(treePopupMenu, SWT.CASCADE);
		addItem.setText(SolVE.i18n.getResourceString("ADD_POPUP"));
		
		addMenu = new Menu(gui.getShell(), SWT.DROP_DOWN);
		
		numberItem = new MenuItem(addMenu, SWT.CASCADE);
		numberItem.setText(SolVE.i18n.getResourceString("NUMBER_POPUP"));
		numberItem.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent arg0) {
				gui.getEventManager().actionInsertDataType(Types.NUMBER);
			}
		}); 
		
		booleanItem = new MenuItem(addMenu, SWT.CASCADE);
		booleanItem.setText(SolVE.i18n.getResourceString("BOOLEAN_POPUP"));
		booleanItem.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent arg0) {
				gui.getEventManager().actionInsertDataType(Types.BOOLEAN);
			}
		});
		
		stringItem = new MenuItem(addMenu, SWT.CASCADE);
		stringItem.setText(SolVE.i18n.getResourceString("STRING_POPUP"));
		stringItem.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent arg0) {
				gui.getEventManager().actionInsertDataType(Types.STRING);
			}
		});
		
		objectItem = new MenuItem(addMenu, SWT.CASCADE);
		objectItem.setText(SolVE.i18n.getResourceString("OBJECT_POPUP"));
		objectItem.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent arg0) {
				gui.getEventManager().actionInsertDataType(Types.OBJECT);
			}
		});
		
		nullItem = new MenuItem(addMenu, SWT.CASCADE);
		nullItem.setText(SolVE.i18n.getResourceString("NULL_POPUP"));
		nullItem.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent arg0) {
				gui.getEventManager().actionInsertDataType(Types.NULL);
			}
		}); 
		
		undefinedItem = new MenuItem(addMenu, SWT.CASCADE);
		undefinedItem.setText(SolVE.i18n.getResourceString("UNDEFINED_POPUP"));
		undefinedItem.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent arg0) {
				gui.getEventManager().actionInsertDataType(Types.UNDEFINED);
			}
		}); 
		
		arrayItem = new MenuItem(addMenu, SWT.CASCADE);
		arrayItem.setText("array"); // TODO: i18n
		arrayItem.setData(new Integer(Types.ARRAY));
		
		SelectionAdapter popupItemSelected = new SelectionAdapter() {
			public void widgetSelected(SelectionEvent se) {
				// holy type-cast BatMan
				gui.getEventManager().actionInsertDataType(((Integer)((MenuItem)se.getSource()).getData()).intValue());
			}
		};
		
		arrayItem.addSelectionListener(popupItemSelected);
		// TODO: use setData on all popup items and add the same
		// listener to all, to save memory and reuse generic event handler
		
		addItem.setMenu(addMenu);
		
		new MenuItem(treePopupMenu, SWT.SEPARATOR);
		
		deleteItem = new MenuItem(treePopupMenu, SWT.CASCADE);
		deleteItem.setText(SolVE.i18n.getResourceString("DELETE_POPUP"));
		deleteItem.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent arg0) {
				gui.getEventManager().actionDeleteFromTree();
			}
		});
		
		// disable the menu by default
		configureMenu(EMPTY_MENU);
	}

	public Menu getTreePopupMenu() {
		return treePopupMenu;
	}
	
	public void configureMenu(int style) {
		switch (style) {
			case CONTAINER_MENU:
				addItem.setEnabled(true);
				deleteItem.setEnabled(true);
				break;
				
			case NON_CONTAINER_MENU:
				addItem.setEnabled(false);
				deleteItem.setEnabled(true);
				break;
				
			case ROOT_MENU:
				addItem.setEnabled(true);
				deleteItem.setEnabled(false);
				break;
				
			case EMPTY_MENU:
				addItem.setEnabled(false);
				deleteItem.setEnabled(false);
				break;
		}
	}
}
