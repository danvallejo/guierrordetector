/*
 * Copyright Notice
 * 
 * (c) 2004 Darron Schall
 * http://solve.sourceforge.net
 * 
 * All rights reserved
 * 
 * 	This program and the accompanying materials are made available under
 *	the terms of the Common Public License v1.0 which accompanies this
 *	distribution, and is available at:  
 *			http://solve.sourceforge.net/cpl-v1.0.html
 *
 * This copyright notice MUST APPEAR in all copies of this file
 *
 * Contributors:
 *			Darron Schall - initial implementation
 */

package com.darronschall.util;

import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.layout.FormLayout;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Shell;

/**
 * @author <a href="mailto:darron@darronschall.com>Darron Schall</a>
 */
public class LayoutUtility {

	private LayoutUtility() {
		// protect class from being instantiated
	}
	
	public static void centerShell(Shell shell) {
		Rectangle displayBounds = shell.getDisplay().getPrimaryMonitor().getBounds();
		Rectangle shellBounds = shell.getBounds();
		int x = displayBounds.x + (displayBounds.width - shellBounds.width) / 2;
		int y = displayBounds.y + (displayBounds.height - shellBounds.height) / 2;
		shell.setLocation(x, y);
	}
	
	public static FillLayout createFillLayout(int marginWidth, int marginHeight) {
		return createFillLayout(marginWidth, marginHeight, 0);
	}
	
	public  static FillLayout createFillLayout(int marginWidth, int marginHeight, int spacing) {
		FillLayout fl = new FillLayout();
		fl.marginWidth = marginWidth;
		fl.marginHeight = marginHeight;
		fl.spacing = spacing;
		return fl;
	}
	
	public static FormLayout createFormLayout(int marginWidth, int marginHeight) {
		return createFormLayout(marginWidth, marginHeight, 0);
	}
	
	public static FormLayout createFormLayout(int marginWidth, int marginHeight, int spacing) {
		FormLayout fl = new FormLayout();
		fl.marginWidth = marginWidth;
		fl.marginHeight = marginHeight;
		fl.spacing = spacing;
		return fl;
	}
	
	public  static GridLayout createGridLayout(int numColumns, int marginWidth, int marginHeight) {
		GridLayout gl = new GridLayout(numColumns, false);
		gl.marginWidth = marginWidth;
		gl.marginHeight = marginHeight;
		return gl;
	}
	
}
