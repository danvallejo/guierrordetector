/*
 * Copyright Notice
 * 
 * (c) 2004 Darron Schall
 * http://solve.sourceforge.net
 * 
 * All rights reserved
 * 
 * 	This program and the accompanying materials are made available under
 *	the terms of the Common Public License v1.0 which accompanies this
 *	distribution, and is available at:  
 *			http://solve.sourceforge.net/cpl-v1.0.html
 *
 * This copyright notice MUST APPEAR in all copies of this file
 *
 * Contributors:
 *			Darron Schall - initial implementation
 */

package com.darronschall.util;

/**
 * @author <a href="mailto:darron@darronschall.com>Darron Schall</a>
 */
public class IntegerUtility {

	private IntegerUtility() {
		// protect class from being instantiated
	}
	
	public static int byteArrayToInt(byte[] data) {
		if (data.length != 4) return 0;
		int v = 0;
		for (int i = 0; i < 3; i++) {
			v += (data[i] & 0xff);
			v <<= 8;
		}
		v += (data[3] & 0xff);
		return v;
	}

	public static short byteArrayToShort(byte[] data) {
		if (data.length != 2) return 0;
		
		short v = (short)(data[0] & 0xff);
		v <<= 8;
		v += data[1];
		return v;
	}
	
	public static byte[] toByteArray(short s) {
		return toByteArray(s, new byte[2]);
	}

	public static byte[] toByteArray(int i) {
		return toByteArray(i, new byte[4]);
	}

	public static byte[] toByteArray(long l) {
		return toByteArray(l, new byte[8]);
	}

	private static byte[] toByteArray(long l, byte[] bytes) {
		for (int i = 0; i < bytes.length; i++) {
			bytes[bytes.length-1-i] = (byte) l;
			l >>>= 8;
		}
		return bytes;
	}
}