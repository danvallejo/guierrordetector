/*
 * Copyright Notice
 * 
 * (c) 2004 Darron Schall
 * http://solve.sourceforge.net
 * 
 * All rights reserved
 * 
 * 	This program and the accompanying materials are made available under
 *	the terms of the Common Public License v1.0 which accompanies this
 *	distribution, and is available at:  
 *			http://solve.sourceforge.net/cpl-v1.0.html
 *
 * This copyright notice MUST APPEAR in all copies of this file
 *
 * Contributors:
 *			Darron Schall - initial implementation
 */

package com.darronschall.util;

import java.io.IOException;

import com.darronschall.solve.gui.SettingsManager;

/**
 * @author <a href="mailto:darron@darronschall.com>Darron Schall</a>
 */
public class BrowserUtility {

	private BrowserUtility() {
		// protect class from being instantiated
	}

	public static void openLink(String href) {
		// Launch default browser on Windows
		if (SettingsManager.isWindows) {
			try { 
				Runtime.getRuntime().exec("rundll32 url.dll,FileProtocolHandler " + href);
			} catch (Exception e) {	
				// TODO: Show error message that browser could not be launched
			}
		}
		// Launch default browser on Mac
		else if (SettingsManager.isMac) {
			try {
				Process proc = Runtime.getRuntime().exec(
						"/usr/bin/open " + href);
			} catch (IOException e) {
				// TODO: Show error message that browser could not be launched 
			}
		}

		else {
			// TODO: launch browser on Linux/Solaris
			return;
		}
	}

}